"""Raiz de composicao.

Este e o unico lugar que sabe como as pecas se encaixam. Os subsistemas recebem
suas dependencias prontas e nunca constroem umas as outras, o que mantem cada um
substituivel e testavel isoladamente.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass
from types import TracebackType

from roboteye.config import LLMSettings, Settings, is_arm
from roboteye.core.assistant import Assistant
from roboteye.core.events import (
    ErrorOccurred,
    Event,
    EventBus,
    ListeningChanged,
    Notice,
    Shutdown,
    SpeechFinished,
    SpeechHeard,
    SpeechStarted,
    ThinkingStarted,
)
from roboteye.face.app import FaceApp
from roboteye.hearing import (
    AvisaAoFecharFrase,
    HearingError,
    Ouvido,
    create_ears,
    dirigido_ao_robo,
)
from roboteye.hearing.gatilho import Conversa
from roboteye.llm.base import LLMClient
from roboteye.llm.factory import create_llm_client
from roboteye.llm.memory import ConversationMemory
from roboteye.llm.persona import PersonaStore
from roboteye.logging_setup import get_logger
from roboteye.speech import sinal
from roboteye.speech.base import SpeechError
from roboteye.speech.envelope import SpeechEnvelope
from roboteye.speech.factory import create_tts_engine
from roboteye.speech.player import create_audio_sink
from roboteye.speech.polish import AudioPolish
from roboteye.speech.speaker import Speaker
from roboteye.ui.console import ConsoleChat

logger = get_logger(__name__)


@dataclass(slots=True)
class Application:
    """Aplicacao montada e pronta para rodar."""

    settings: Settings
    bus: EventBus
    llm: LLMClient
    memory: ConversationMemory
    speaker: Speaker
    assistant: Assistant
    #: Ponte entre o audio que toca e a face que o anima. O locutor escreve,
    #: a face le; e por isso que ele nasce aqui, e nao dentro de um dos dois.
    envelope: SpeechEnvelope
    #: None quando a escuta esta desligada, que e o padrao.
    ears: Ouvido | None = None
    _ouvindo: threading.Thread | None = None
    #: Relogio do "Oi?" — armado ao ser chamada, cancelado quando a pergunta vem.
    _chamado: threading.Timer | None = None
    #: A janela de "fui chamada ha pouco". Nasce em `_escutar`; o sinal de fim
    #: de captura a consulta para nao apitar quando e a sala que esta falando.
    _conversa: Conversa | None = None
    #: Se o sinal de "peguei sua pergunta" ja saiu neste turno. Ver
    #: `_avisar_que_peguei_a_pergunta`.
    _avisei_do_fim: bool = False
    #: Rede de seguranca da pausa da escuta. Um microfone que fica pausado e um
    #: robo surdo — pior que um lento —, entao a pausa tem prazo de validade.
    _destravar_escuta: threading.Timer | None = None

    # -- construcao --------------------------------------------------------
    @classmethod
    def build(cls, settings: Settings) -> Application:
        """Instancia todos os subsistemas sem ainda carregar modelos."""
        bus = EventBus()

        persona_store = PersonaStore(settings.llm.persona_dir, settings.llm.persona)
        persona = persona_store.load(settings.llm.reply_language)
        logger.info("persona %r carregada (%d fatos aprendidos)", persona.name, len(persona.facts))
        _conferir_o_tamanho_da_persona(persona.system_prompt(), settings.llm)

        memory = ConversationMemory(
            persona.system_prompt(),
            max_messages=settings.llm.history_messages,
        )

        llm = create_llm_client(settings.llm)
        envelope = SpeechEnvelope()

        def announce_voice_switch(message: str) -> None:
            # Aviso, nao erro: a fala continua, entao a face nao deve ficar brava
            # nem interromper o que esta dizendo. Mas precisa aparecer — trocar
            # de voz em silencio faz quem ouve procurar o problema na
            # configuracao, que e o unico lugar onde ele nao esta.
            logger.warning("%s", message)
            bus.publish(Notice(message=message, source="speech"))

        speaker = Speaker(
            engine=create_tts_engine(settings.voice, on_voice_switch=announce_voice_switch),
            sink=create_audio_sink(settings.voice),
            bus=bus,
            envelope=envelope,
            language=settings.voice.language,
            polish=AudioPolish(gain=settings.voice.gain),
        )
        assistant = Assistant(
            llm=llm,
            memory=memory,
            speaker=speaker,
            bus=bus,
            persona=persona_store,
            language=settings.llm.reply_language,
        )

        return cls(
            settings=settings,
            bus=bus,
            llm=llm,
            memory=memory,
            speaker=speaker,
            assistant=assistant,
            envelope=envelope,
            ears=create_ears(settings.hearing),
        )

    # -- ciclo de vida -----------------------------------------------------
    def start(self, *, warm_up: bool = True) -> None:
        """Sobe as threads de trabalho e, opcionalmente, pre-carrega a voz."""
        self.speaker.start()
        self.assistant.start()

        if warm_up:
            try:
                self.speaker.warm_up()
            except SpeechError as exc:
                logger.warning("voz indisponivel: %s", exc)
                self.bus.publish(ErrorOccurred(message=str(exc), source="speech"))

            # O LLM aquece em segundo plano: nao ha razao para segurar a face
            # esperando o modelo subir na GPU. Vai junto a persona, que e o que
            # a conversa vai usar de verdade — ver `OllamaClient.warm_up`.
            threading.Thread(
                target=self.llm.warm_up,
                args=(self.assistant.memory.build_prompt(),),
                name="llm-warmup",
                daemon=True,
            ).start()

        self._abrir_ouvidos()
        self._dar_bom_dia()

    def _dar_bom_dia(self) -> None:
        """Fala a primeira frase, se houver uma configurada.

        Numa thread porque a sintese da primeira frase carrega o motor de voz, e
        segurar o arranque nela deixaria a tela preta por segundos.
        """
        frase = self.settings.llm.saudacao.strip()
        if not frase:
            return

        def falar() -> None:
            try:
                self.assistant.say_directly(frase)
            except Exception as exc:
                # Sem passar pelo LLM: e uma frase fixa, e ela precisa sair
                # mesmo com a IA fora do ar. Falhando, o robo sobe calado — o
                # que ja e a informacao que a saudacao existe para dar.
                logger.warning("nao consegui dar bom dia: %s", exc)

        threading.Thread(target=falar, name="saudacao", daemon=True).start()

    def _abrir_ouvidos(self) -> None:
        """Poe o robo para escutar, se houver microfone configurado."""
        if self.ears is None or self._ouvindo is not None:
            return

        # A Atlas nao pode se ouvir: o microfone esta a centimetros da caixinha,
        # e sem isto ela transcreve a propria voz e responde a si mesma, em laco.
        # Os eventos de fala ja existem — so faltava alguem escutar por eles.
        ouvido = self.ears
        self.bus.subscribe(lambda _e: ouvido.pausar(), event_type=SpeechStarted)
        self.bus.subscribe(lambda _e: self._voltar_a_escutar(), event_type=SpeechFinished)

        # **Pensar e transcrever nao cabem juntos em quatro nucleos.**
        #
        # O Ollama usa todos os nucleos que encontra e o reconhecimento pede
        # tres; somando a face, sao oito threads disputando quatro. Medido neste
        # Pi, a mesma pergunta ao mesmo modelo:
        #
        #     sozinho              primeiro token   200 ms   resposta   1,4 s
        #     disputando           primeiro token  3300 ms   resposta  24,6 s
        #
        # Dez vezes mais lento — e foi assim que uma resposta estourou o teto de
        # 60 s e o robo nao respondeu nada. A escuta para enquanto ela pensa: o
        # robo ja esta comprometido com a pergunta que recebeu, e transcrever a
        # sala nesse meio-tempo custa justamente a resposta.
        self.bus.subscribe(self._parar_de_escutar_para_pensar, event_type=ThinkingStarted)
        # Um turno que falha nao passa por `SpeechFinished`: a escuta voltaria
        # so no proximo, e ate la o robo estaria surdo.
        self.bus.subscribe(lambda _e: self._voltar_a_escutar(), event_type=ErrorOccurred)

        # Chamar o nome e ficar no silencio e a pior parte de conversar com este
        # robo: quem falou nao sabe se foi ouvido, entao repete o nome — e a
        # repeticao chega justo enquanto a primeira ainda esta sendo tratada. Um
        # som curto fecha esse buraco na hora, sem esperar sintese nenhuma.
        self.bus.subscribe(self._avisar_que_estou_ouvindo, event_type=ListeningChanged)

        # E o outro lado do par: um som ao fechar a captura da frase seguinte,
        # para quem perguntou saber que pode parar de falar. Vem do microfone e
        # nao do reconhecimento de proposito — esperar a transcricao custaria
        # quase dois segundos, e o aviso chegaria depois de a pessoa ja ter
        # desistido de esperar.
        if isinstance(ouvido, AvisaAoFecharFrase):
            ouvido.ao_fechar_frase(self._avisar_que_terminei_de_ouvir)

        self._ouvindo = threading.Thread(target=self._escutar, name="ouvidos", daemon=True)
        self._ouvindo.start()

    def _escutar(self) -> None:
        """Roda a escuta e entrega ao assistente o que foi dirigido ao robo."""
        assert self.ears is not None
        # Chamar o nome abre uma janela em que a frase seguinte e aceita sem
        # ele — que e como as pessoas falam: "Atlas!" ... "quanto e dois mais dois?"
        conversa = Conversa(self.settings.hearing.janela_s)
        # Guardada tambem no objeto: quem avisa o fim da captura roda a partir
        # do microfone e precisa saber se a janela esta aberta.
        self._conversa = conversa
        try:
            for transcricao in self.ears.escutar():
                pergunta = dirigido_ao_robo(
                    transcricao.texto, self.settings.hearing.wake_word, conversa=conversa
                )
                # Publicado para toda transcricao, dirigida ou nao: a tela de
                # debug mostra ate o que o robo ouviu e ignorou, que e metade do
                # trabalho de descobrir por que ele nao respondeu.
                self.bus.publish(
                    SpeechHeard(
                        raw=transcricao.texto,
                        accepted=pergunta,
                        ms=transcricao.ms,
                        confidence=transcricao.confianca,
                        no_speech=transcricao.sem_fala,
                    )
                )
                if pergunta is None:
                    # INFO, e nao debug: "o robo nao me escuta" e a queixa mais
                    # comum, e sem esta linha nao ha como saber se ele nao
                    # ouviu, ouviu errado, ou ouviu e achou que nao era com ele
                    # — tres problemas diferentes, com tres consertos
                    # diferentes. So aparece quando houve transcricao de
                    # verdade, entao uma sala quieta nao enche o log.
                    logger.info("ouvi %r, mas nao era comigo", transcricao.texto)
                    # Chamada sem pergunta ("Atlas!") abre a janela: a face
                    # mostra que esta esperando, que e o unico jeito de quem
                    # falou saber que foi ouvido antes de fazer a pergunta.
                    if conversa.aberta():
                        self.bus.publish(ListeningChanged(active=True))
                        self._perguntar_se_ficou_no_ar()
                    continue
                logger.info("ouvi: %s", pergunta)
                self._cancelar_pergunta()
                self.bus.publish(ListeningChanged(active=False))
                self._avisar_que_peguei_a_pergunta()
                self.assistant.submit(pergunta)
        except HearingError as exc:
            logger.warning("escuta indisponivel: %s", exc)
            self.bus.publish(ErrorOccurred(message=str(exc), source="hearing"))
        except Exception:
            logger.exception("a escuta parou")

    def _avisar_que_estou_ouvindo(self, evento: Event) -> None:
        """Toca o sinal quando a janela de escuta abre. So na abertura.

        Fechar a janela nao merece som: ou veio a pergunta — e a resposta e o
        aviso —, ou o tempo passou, e um som para "desisti de esperar" so
        atrapalha quem ja voltou a fazer outra coisa.
        """
        if not isinstance(evento, ListeningChanged) or not evento.active:
            return
        try:
            self.speaker.sinalizar(sinal.escutando())
            logger.info("sinal: estou ouvindo, pode perguntar")
        except Exception as exc:
            # O sinal e conforto, nao funcao: falhar aqui nao pode impedir o
            # robo de ouvir a pergunta que vem em seguida.
            logger.debug("nao consegui tocar o sinal de escuta: %s", exc)

    def _parar_de_escutar_para_pensar(self, _evento: Event) -> None:
        """Cala o microfone enquanto ela pensa, com prazo de validade.

        A pausa em si e o que devolve os nucleos ao modelo. O prazo e a rede de

        seguranca: os eventos cobrem os caminhos conhecidos, mas um microfone
        que fica pausado e um robo surdo — e um robo surdo e pior que um lento.
        O relogio garante que a escuta volta mesmo que um caminho novo esqueca
        de avisar. O prazo e o do proprio modelo, com folga: se ele estourou, ja
        nao ha resposta a proteger.
        """
        if self.ears is not None:
            self.ears.pausar()
        self._cancelar_destravamento()
        timer = threading.Timer(self.settings.llm.timeout + 15.0, self._voltar_a_escutar)
        timer.daemon = True
        self._destravar_escuta = timer
        timer.start()

    def _cancelar_destravamento(self) -> None:
        if self._destravar_escuta is not None:
            self._destravar_escuta.cancel()
            self._destravar_escuta = None

    def _voltar_a_escutar(self) -> None:
        """Fim do turno: a escuta volta e o proximo sinal fica liberado."""
        self._cancelar_destravamento()
        self._avisei_do_fim = False
        if self.ears is not None:
            self.ears.retomar()

    def _avisar_que_peguei_a_pergunta(self) -> None:
        """O sinal de "peguei, estou pensando", quando ele ainda nao saiu.

        No caminho de duas etapas ("Atlas" ... pergunta) ele ja saiu la atras,
        no fim da captura — 1,9 s antes, porque nao esperou a transcricao. Mas
        quem pergunta tudo de uma vez ("Atlas, qual seu nome?") nao abre janela
        nenhuma, e nao ouvia sinal algum: a primeira coisa que chegava era a
        resposta, e ate ela o robo parecia nao ter escutado.
        """
        if self._avisei_do_fim:
            return
        try:
            self.speaker.sinalizar(sinal.ouvi())
            logger.info("sinal: peguei sua pergunta")
        except Exception as exc:
            logger.debug("nao consegui tocar o sinal de pergunta recebida: %s", exc)

    def _avisar_que_terminei_de_ouvir(self) -> None:
        """Toca o sinal de fecho quando a captura de uma frase termina.

        **So com a janela aberta.** Um microfone aberto numa sala fecha uma
        captura a cada frase que alguem diz por perto, e sem esta guarda o robo
        apitaria o dia inteiro para conversas que nao sao com ele. Com a janela
        aberta, o que acabou de fechar e quase certamente a pergunta.

        Quem pergunta tudo de uma vez ("Atlas, quantos alunos tem?") nao ouve
        este sinal: a janela so abre quando o nome vem sozinho. Nesse caso o
        aviso e a propria resposta, que chega logo.
        """
        if self._conversa is None or not self._conversa.aberta():
            return
        try:
            self.speaker.sinalizar(sinal.ouvi())
            self._avisei_do_fim = True
            logger.info("sinal: terminei de ouvir")
        except Exception as exc:
            logger.debug("nao consegui tocar o sinal de fim de escuta: %s", exc)

    def _perguntar_se_ficou_no_ar(self) -> None:
        """Diz "Oi?" se chamarem o nome e a pergunta nao vier.

        Ser chamada e nao responder nada parece robo quebrado — e quem chamou
        repete o nome, em vez de perguntar. Um "Oi?" fecha esse silencio.
        """
        frase = self.settings.hearing.resposta_ao_chamado.strip()
        if not frase:
            return

        self._cancelar_pergunta()
        timer = threading.Timer(
            self.settings.hearing.espera_do_chamado_s,
            self._dizer_oi,
            args=(frase,),
        )
        timer.daemon = True
        self._chamado = timer
        timer.start()

    def _cancelar_pergunta(self) -> None:
        if self._chamado is not None:
            self._chamado.cancel()
            self._chamado = None

    def _dizer_oi(self, frase: str) -> None:
        # A pergunta pode ter chegado enquanto o relogio corria; responder
        # "Oi?" por cima dela seria falar junto com quem perguntou.
        if self.assistant.is_busy:
            return
        try:
            self.assistant.say_directly(frase)
        except Exception as exc:
            logger.debug("nao consegui responder ao chamado: %s", exc)

    def shutdown(self) -> None:
        """Encerra tudo na ordem inversa da criacao."""
        logger.debug("encerrando aplicacao")
        self._cancelar_pergunta()
        self._cancelar_destravamento()
        if self.ears is not None:
            self.ears.close()
        self.assistant.close()
        self.speaker.close()

    def __enter__(self) -> Application:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.shutdown()

    # -- modos de execucao -------------------------------------------------
    def run_chat(self) -> None:
        """Somente terminal: sem janela, sem pygame."""
        self.start()
        console = ConsoleChat(self.assistant, self.bus)
        try:
            console.run()
        finally:
            self.shutdown()

    def run_face(self) -> None:
        """A face animada, sem chat no terminal.

        Aquece assim mesmo. Antes nao aquecia — sem entrada de texto nao havia
        conversa a preparar —, mas hoje ha: a pagina do celular conversa, e e
        justamente por ela que alguem fala com o robo instalado. Sem aquecer, a
        primeira pergunta feita ali pagaria os segundos de carregar o modelo e
        ler a persona (ver `OllamaClient.warm_up`), que e o custo que este
        projeto passou a pagar no arranque de proposito.
        """
        self.start()
        face = FaceApp(self.settings.face, self.bus, envelope=self.envelope)
        try:
            face.run()
        finally:
            self.shutdown()

    def run_interactive(self) -> None:
        """Face na thread principal e chat de texto em segundo plano."""
        if not self.settings.face.enabled:
            self.run_chat()
            return

        self.start()

        face = FaceApp(self.settings.face, self.bus, envelope=self.envelope)
        console = ConsoleChat(self.assistant, self.bus)

        # Fechar a janela deve encerrar o chat, e vice-versa.
        self.bus.subscribe(_stop_on_shutdown(face), event_type=Shutdown)

        console.start_background()
        try:
            face.run()
        finally:
            console.stop()
            self.shutdown()


#: Aproximacao de tokens a partir de caracteres. Nao vale contar de verdade
#: aqui: exigiria carregar o tokenizador do modelo no arranque, e a conta so
#: precisa acertar a ordem de grandeza.
#:
#: 3,7 e o que este texto de fato deu, e nao a regra de bolso de 4: a persona
#: de 7198 caracteres virou ~1950 tokens no `gemma3:1b` (o Ollama registrou
#: 1968 com a pergunta junto). Portugues com acento rende menos caractere por
#: token que ingles, e usar 4 subestimava o prompt em quase 10% — justo na
#: direcao que faz o aviso nao aparecer.
_CARACTERES_POR_TOKEN = 3.7

#: Quantos tokens de prompt o robo le por segundo quando o cache esta frio.
#: Medido neste Pi 5 com o `gemma3:1b`, nas tres marcas que o Ollama registra:
#: 39, 34 e 32 tokens/s. Numa maquina de mesa e uma ordem de grandeza mais
#: rapido, e por isso o aviso so vale a pena onde ele doi.
_TOKENS_POR_SEGUNDO_NO_PI = 35.0
_TOKENS_POR_SEGUNDO_NO_RESTO = 600.0

#: A partir de quantos segundos de leitura a persona vira o problema.
#:
#: Trinta, e nao quinze: num Pi qualquer prompt custa cerca de um segundo por
#: 35 tokens quando o cache esfria, e ate uma persona modesta de ~500 tokens
#: gasta quinze. Avisar sobre ela seria avisar sempre, e um aviso que aparece
#: sempre ensina a ser ignorado. Trinta segundos ja e o dobro do normal — ali a
#: persona virou de fato a coisa mais cara do arranque.
#:
#: Para o caso comum, a resposta certa nao e encurtar a persona: e nao deixar o
#: cache esfriar. Ver `KEEP_ALIVE_EM_USO` em `llm/fallback.py`.
_SEGUNDOS_QUE_PREOCUPAM = 30.0


def _conferir_o_tamanho_da_persona(prompt: str, llm: LLMSettings) -> None:
    """Avisa quando ler a persona custa mais que responder.

    Um prompt grande nao da erro: da **lentidao**, e de um jeito que nao aponta
    para ele. Cada vez que o cache do modelo esfria, o prompt inteiro e relido
    antes de a resposta comecar. Medido neste robo, com 1968 tokens:

        prompt processing  512/1968   39 tokens/s
        [GIN] 500 | 1m0s | POST "/api/chat"

    Sessenta segundos sem chegar ao primeiro token. Quem investiga isso olha o
    modelo, a rede e a voz — tudo menos o arquivo de texto da personalidade.
    Esta linha e para o log dizer de uma vez.

    O aviso e sobre **tempo**, e nao sobre fracao da janela: a mesma persona
    que trava um Raspberry Pi passa despercebida numa maquina de mesa, e um
    aviso que aparece nas duas ensina a ignora-lo.
    """
    tokens = int(len(prompt) / _CARACTERES_POR_TOKEN)
    taxa = _TOKENS_POR_SEGUNDO_NO_PI if is_arm() else _TOKENS_POR_SEGUNDO_NO_RESTO
    segundos = tokens / taxa

    # Nao cabe junto com a resposta: o Ollama passa a deslocar a janela no meio
    # da geracao, que e caro e piora o texto.
    transborda = tokens + llm.max_tokens > llm.num_ctx

    if segundos < _SEGUNDOS_QUE_PREOCUPAM and not transborda:
        logger.debug("persona ocupa ~%d tokens de %d", tokens, llm.num_ctx)
        return

    logger.warning(
        "a persona ocupa ~%d dos %d tokens de contexto. Cada vez que o cache do "
        "modelo esfriar, le-la custa ~%.0fs antes da primeira palavra da "
        "resposta%s — encurtar persona/%s.md e o que mais acelera este robo.",
        tokens,
        llm.num_ctx,
        segundos,
        ", e ela nao cabe junto com a resposta" if transborda else "",
        llm.persona,
    )


def _stop_on_shutdown(face: FaceApp):
    def handler(_: Event) -> None:
        face.request_stop()

    return handler
