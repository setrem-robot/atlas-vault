---
title: "GPS — implementação e integração pendente"
tipo: modulo
estado_documental: revisado
atualizado: 2026-09-09
tags:
  - atlas
  - modulo
---

# GPS — implementação e integração pendente

O serviço `pi/services/gps` lê uma serial com `pyserial`, interpreta NMEA com `pynmea2` e acumula campos na classe `Posicao`. GGA fornece posição, fix e satélites; RMC acrescenta velocidade/rumo. A velocidade é convertida de nós para km/h.

Publicação de domínio: `robo/gps/posicao`. Espelhamento: `robo/telemetria/gps`. A posição válida exige fix e coordenadas disponíveis; o período é configurável por `GPS_INTERVALO_S`.

```json
{"lat":-28.2,"lon":-54.0,"fix":true,"satelites":7,"altitude_m":300.0,"velocidade_kmh":1.2,"rumo":90.0,"ts":1788969600}
```

Este payload é **exemplo ilustrativo** de formato, não leitura coletada do robô. Configure `GPS_PORT` e `GPS_BAUD` de acordo com o módulo identificado. Não foi encontrado inventário confiável do modelo físico ou da pinagem GPS atual.

## Pendência confirmada para este semestre

O usuário pediu implementar o GPS. O README atual informa que ele não está montado, apesar da conclusão histórica declarar integração. A tarefa é verificar módulo/ligação, observar sentenças reais, obter fix, conferir posição no MQTT, no banco e nas telas e testar perda de fix/reconexão.

O código não deve confundir última coordenada conhecida com posição atual válida. Esse comportamento, incluindo envelhecimento do fix e carimbo de tempo, precisa fazer parte do teste. A existência do serviço não demonstra precisão nem disponibilidade de sinal no campus.

[[wiki/estado/divergencias]] · [[wiki/planejamento/validacao]] · [[wiki/api/contratos]].

## Fontes e conferência

- [orquestrador/pi/services/gps/src/gps/main.py](https://github.com/setrem-robot/orquestrador/blob/98ee681498e05426ff47041ae7f8e7ec97d0ffaf/pi/services/gps/src/gps/main.py)
- [orquestrador/README.md](https://github.com/setrem-robot/orquestrador/blob/98ee681498e05426ff47041ae7f8e7ec97d0ffaf/README.md)
- [[fontes/relatorios/OrquestradorPDF.pdf#page=38]]

---
[[INICIO|Início]] · [[wiki/meta/fontes|Fontes e limites da documentação]]
