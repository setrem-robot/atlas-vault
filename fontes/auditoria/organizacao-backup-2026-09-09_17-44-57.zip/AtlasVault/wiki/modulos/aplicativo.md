---
title: "Aplicativo — controle e informações"
tipo: modulo
estado_documental: revisado
atualizado: 2026-09-09
tags:
  - atlas
  - modulo
---

# Aplicativo — controle e informações

**Pasta:** `app` · **Repo:** `aplicativo` · **Versão declarada:** `1.2.2+9`.

## Organização

| Pasta/arquivo em `lib` | Responsabilidade |
|---|---|
| `main.dart`, `app/theme.dart`, `app/versao.dart` | Entrada, aparência e versão visível |
| `screens/connect_screen.dart` | Descoberta e conexão BLE; acesso à telemetria |
| `screens/control_screen.dart` | Direcional e desconexão |
| `screens/telemetria_screen.dart` | Abas Agora, Trajeto, Histórico e Eventos |
| `screens/rota_segura_screen.dart` | Planejamento de caminho e envio |
| `screens/ajustes_api_screen.dart` | Endereço e token da API |
| `services/robot_connection.dart` | Transporte BLE, repetição e envio de rota |
| `services/telemetry_api.dart` | Acesso HTTP e configuração persistida |
| `services/rota_store.dart` | Persistência da rota no aparelho |
| `models/robot_command.dart` | Comandos compactos |
| `models/telemetria.dart`, `models/rota_segura.dart` | Dados de telemetria e rota |
| `widgets` | Direcional, mapas, frescor do dado, gráficos e painéis |

## Funcionalidades e limites

O controle BLE é independente da internet. A visualização remota usa API e pode consultar histórico com o robô desligado. A parada depende de soltar/cancelar o botão e do vigia no serviço de motores. A rota é desenhada, salva e enviada em mensagens `inicio`, `ponto`, `fim`; isso não faz o robô percorrê-la autonomamente.

O projeto contém pastas Android, iOS, Linux, Windows, macOS e web, mas a presença de uma pasta de plataforma não comprova validação do BLE em todas elas. O alvo declarado é Android/iOS; a esteira de distribuição atual cobre Android.

## Distribuição

O workflow `deploy.yml` integra Shorebird. Alteração em Dart pode ser entregue por patch conforme o fluxo configurado; recursos e código nativo exigem nova release. Conferir a execução real do workflow antes de declarar uma distribuição concluída. Não houve build nem publicação nesta sessão.

Configuração salva pelo usuário prevalece sobre valores padrão da build. O app pode continuar apontando a uma API antiga após atualizar; revisar Ajustes antes de atribuir a falha ao código.

## Testes e continuidade

Existem testes de comando, direcional, telemetria e rota segura. Os comandos de verificação são `flutter analyze` e `flutter test`. Não foram executados nesta organização documental.

Próxima melhoria: retorno claro de conexão/recepção/execução, ensaios de desconexão e dados reais no mapa. [[wiki/planejamento/backlog]] · [[wiki/api/contrato-mqtt]].

## Fontes e conferência

- [app/ARQUITETURA.md](https://github.com/setrem-robot/aplicativo/blob/44d500160ecf13d7d1db2a4fe0c54052d352c0aa/ARQUITETURA.md)
- [app/README.md](https://github.com/setrem-robot/aplicativo/blob/44d500160ecf13d7d1db2a4fe0c54052d352c0aa/README.md)
- [app/.github/workflows/deploy.yml](https://github.com/setrem-robot/aplicativo/blob/44d500160ecf13d7d1db2a4fe0c54052d352c0aa/.github/workflows/deploy.yml)
- [app/lib/services/robot_connection.dart](https://github.com/setrem-robot/aplicativo/blob/44d500160ecf13d7d1db2a4fe0c54052d352c0aa/lib/services/robot_connection.dart)

---
[[INICIO|Início]] · [[wiki/meta/fontes|Fontes e limites da documentação]]
