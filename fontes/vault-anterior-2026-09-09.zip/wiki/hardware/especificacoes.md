# Hardware — Especificações

Componentes, pinagem, esquemático e dimensionamento da plataforma SetremBot.

---

## 🧠 Processadores

### ESP32 Dev Board

| Parâmetro | Valor |
|-----------|-------|
| **Processador** | Xtensa 32-bit, 240 MHz, dual-core |
| **RAM** | 320 KB (SRAM) + 4 MB (PSRAM opcional) |
| **Flash** | 4 MB |
| **GPIO** | 34 pinos (28 usáveis) |
| **Periféricos** | UART, SPI, I2C, ADC, PWM, BLE, WiFi |
| **Alimentação** | 5V USB ou 3.3V pin |
| **Consumo típico** | 80 mA (idle), 200 mA (BLE ativo) |

**Pinagem usada:**
- UART RX/TX: GPIO 3/1 (conecta ao Pi)
- BLE: nativo (rádio integrado)

### Raspberry Pi 4B

| Parâmetro | Valor |
|-----------|-------|
| **SoC** | Broadcom BCM2711, ARM Cortex-A72, 1.5 GHz, quad-core |
| **RAM** | 2 / 4 / 8 GB (LPDDR4) |
| **Storage** | microSD (64 GB recomendado) |
| **GPIO** | 40 pinos (26 usáveis) |
| **Periféricos** | UART, SPI, I2C, PWM (via gpiozero), USB 3.0 |
| **Ethernet** | Gigabit |
| **WiFi** | 802.11ac (2.4 e 5 GHz) |
| **Bluetooth** | 5.0 |
| **Alimentação** | USB-C (5.1V, 3A) |
| **Consumo típico** | 600 mA (idle), 1000 mA (pico) |

**Setup esperado:** 4 GB RAM, OS: Raspberry Pi OS (Bullseye ou newer)

---

## 🔌 Periféricos Conectados ao Pi

### GPIO para Motores (TMC2209 Steppers)

| Função | GPIO | Pino | Observação |
|--------|------|------|-----------|
| **Motor Esquerdo STEP** | GPIO 17 | 11 | PWM output, ~5000 Hz max |
| **Motor Esquerdo DIR** | GPIO 18 | 12 | Digital output |
| **Motor Direito STEP** | GPIO 27 | 13 | PWM output, ~5000 Hz max |
| **Motor Direito DIR** | GPIO 22 | 15 | Digital output |

**Acionamento via gpiozero/lgpio:**
```python
from gpiozero import PWMLED, DigitalOutputDevice
from gpiozero.pins.lgpio import LGPIOFactory

factory = LGPIOFactory()
pwm_step_esq = PWMLED(17, pin_factory=factory)
pwm_step_dir = PWMLED(27, pin_factory=factory)
dir_esq = DigitalOutputDevice(18, pin_factory=factory)
dir_dir = DigitalOutputDevice(22, pin_factory=factory)

# Aplicar velocidade (0 a 1)
pwm_step_esq.value = 0.5  # 50% duty cycle = 2500 Hz (se freq=5000)
dir_esq.on()  # 1 = frente, 0 = ré
```

### UART Serial (ESP32 ↔ Pi)

| Função | Pi GPIO | Pino | Observação |
|--------|---------|------|-----------|
| **RX** | GPIO 15 (Alt) | 10 | Recebe do ESP32 |
| **TX** | GPIO 14 (Alt) | 8 | Envia ao ESP32 |

**Ou USB direto:** `/dev/ttyUSB0` (USB serial adapter)

**Configuração:**
```python
import serial
ser = serial.Serial("/dev/ttyUSB0", baudrate=115200, timeout=1)
```

### GPS u-blox (opcional)

| Função | Pi GPIO/Porta | Observação |
|--------|---------------|-----------|
| **RX** | `/dev/ttyUSB1` | Segunda porta USB serial |
| **TX** | `/dev/ttyUSB1` | |
| **GND** | GND | Referência comum |

**Comunicação:** NMEA 0183 a 9600 baud (padrão)

### Sensor de Bateria (ADC)

| Função | Pino | Observação |
|--------|------|-----------|
| **Tensão (V)** | GPIO 26 (ADC0) | 3.3V max → divisor 1:4 |
| **Corrente (A)** | GPIO 27 (ADC1) | INA219 (I2C) recomendado |

---

## ⚙️ Motores & Cinemática

### NEMA17 + TMC2209

| Parâmetro | Valor |
|-----------|-------|
| **Tipo** | Stepper motor NEMA17 |
| **Torque** | 0.4 Nm (nominal) |
| **Passos/volta** | 200 (1.8° per step) |
| **Microstepping** | 16x (recomendado) = 3200 passos/volta |
| **Max RPM** | ~300 (14000 passos/s / 3200 * 60) |

**Driver TMC2209:**
- Corrente máxima: 2.0 A
- Microstepping: 1, 2, 4, 8, 16x
- Modo Step/Dir (compatível com Raspberry Pi)

### Redução Mecânica

| Componente | Redução | Observação |
|-----------|---------|-----------|
| **Motor** | 1:1 | Saída do eixo |
| **Redução** | 1:13 | Caixa de redução (assumido) |
| **Roda** | Ø 100 mm | Diâmetro (assumido) |

**Velocidade final:**
```
Passos/s = 5000 (máximo PWM)
Voltas/s = 5000 / 3200 = 1.56 voltas/s = 93.75 RPM
Velocidade linear = RPM * (π * D) / 60 = 93.75 * π * 0.1 / 60 ≈ 0.49 m/s
```

### Cinemática Diferencial (Skid-Steer)

```python
# Configuração: dois motores independentes, sem centragem

def comando_para_velocidade(cmd):
    """Converte F/R/L/D em velocidade de cada lado."""
    if cmd == "F":
        return {"esq": 0.5, "dir": 0.5}      # Frente
    elif cmd == "R":
        return {"esq": -0.5, "dir": -0.5}    # Ré
    elif cmd == "L":
        return {"esq": -0.5, "dir": 0.5}     # Rotação CCW
    elif cmd == "D":
        return {"esq": 0.5, "dir": -0.5}     # Rotação CW
    elif cmd == "S":
        return {"esq": 0, "dir": 0}          # Parada
```

---

## 🔋 Sistema de Energia

### Bateria

| Especificação | Valor | Observação |
|---------------|-------|-----------|
| **Tipo** | LiPo 4S | 14.8V nominal |
| **Capacidade** | 5000 mAh | Duração: ~2-3h em uso contínuo |
| **Conector** | XT60 | Padrão FPV |
| **BMS** | Sim | Proteção contra sobrecarga/descarga |

### Reguladores

| Saída | Entrada | Corrente | Observação |
|-------|---------|----------|-----------|
| **5V (Lógica)** | 12V (bateria) | 3A | SMPS para Pi, ESP32, sensores |
| **12V (Motores)** | 14.8V (direto) | 10A | Drivers TMC2209 |

**Dimensionamento:**
- Pi 4B: ~600 mA (idle) a 1000 mA (pico)
- ESP32: ~200 mA
- Sensores: ~100 mA
- Total lógica: ~1.3 A (headroom: 3A @ 5V)
- Motores: ~2A (cada um) @ 12V = 4A pico (dois motores)
- Total geral: ~30 A pico @ bateria (superdimensionado com BMS)

---

## 📐 Geometria & Peso

### Dimensões Físicas

```
        Topo
    ┌────────────┐
    │   ESP32    │  Altura: ~10 cm
    │    │       │
    │┌──┴──────┐ │  Comprimento: ~30 cm
    ││ Pi      │ │  Largura: ~20 cm
    ││ +       │ │  Distância entre rodas: ~15 cm
    │└──┬──────┘ │
    │ [O] [O]    │  [O] = roda motora
    └────────────┘
      Bateria abaixo
```

### Peso Estimado

| Componente | Peso |
|-----------|------|
| Chassis/frame | 200 g |
| Bateria LiPo | 300 g |
| Raspberry Pi | 60 g |
| ESP32 + regulador | 50 g |
| Motores + redução | 400 g (2x) |
| Rodas | 100 g (4x) |
| Fios, conectores | 100 g |
| **Total** | ~1.4 kg |

**Centro de massa:** Levemente à frente das rodas (2-3 cm) → estável.

---

## 🧪 Testes de Hardware

### Teste: Motor Esquerdo

```bash
python3 << 'EOF'
from gpiozero import PWMLED, DigitalOutputDevice
from gpiozero.pins.lgpio import LGPIOFactory
import time

factory = LGPIOFactory()
pwm_esq = PWMLED(17, pin_factory=factory)
dir_esq = DigitalOutputDevice(18, pin_factory=factory)

# Frente
dir_esq.on()
for i in range(10):
    pwm_esq.value = i / 10
    print(f"PWM: {pwm_esq.value:.1f}")
    time.sleep(0.5)

# Parada
pwm_esq.off()
EOF
```

### Teste: GPS

```bash
cat /dev/ttyUSB1
# Esperado (NMEA):
# $GPRMC,123519,4807.038,N,01131.000,E,022.4,084.4,230394,003.1,W*6A
```

### Teste: ADC Bateria

```bash
python3 << 'EOF'
import board
import busio
import adafruit_ads1x15.ads1115 as ADS
from adafruit_ads1x15.analog_in import AnalogIn

i2c = busio.I2C(board.SCL, board.SDA)
ads = ADS.ADS1115(i2c)

# Pino A0 = tensão da bateria (com divisor 4:1)
channel_0 = AnalogIn(ads, ADS.P0)

while True:
    voltage = channel_0.voltage * 4  # Desconta o divisor
    print(f"Tensão: {voltage:.2f} V")
    time.sleep(1)
EOF
```

---

## ⚡ Pinagem Resumida (GPIO Pi)

```
      3.3V [1]  [2]  5V
       SDA [3]  [4]  5V
       SCL [5]  [6]  GND
      GPIO4 [7]  [8]  GPIO14 (TX alt)
       GND [9]  [10] GPIO15 (RX alt)
     GPIO17 [11] [12] GPIO18 ← Motores
     GPIO27 [13] [14] GND
     GPIO22 [15] [16] GPIO23
      3.3V [17] [18] GPIO24
     GPIO10 [19] [20] GND
      GPIO9 [21] [22] GPIO25
     GPIO11 [23] [24] GPIO8
       GND [25] [26] GPIO7
      GPIO0 [27] [28] GPIO1
      GPIO5 [29] [30] GND
      GPIO6 [31] [32] GPIO12
     GPIO13 [33] [34] GND
     GPIO19 [35] [36] GPIO16
     GPIO26 [37] [38] GPIO20 ← ADC (alternativa)
       GND [39] [40] GPIO21
```

**Uso:**
- [11] GPIO17 → Motor esq STEP
- [12] GPIO18 → Motor esq DIR
- [13] GPIO27 → Motor dir STEP
- [15] GPIO22 → Motor dir DIR
- [8] GPIO14 → UART TX (alternativa)
- [10] GPIO15 → UART RX (alternativa)

---

Veja também: [[../configuracao/setup-completo.md]], [[../modulos/python-services.md]]
