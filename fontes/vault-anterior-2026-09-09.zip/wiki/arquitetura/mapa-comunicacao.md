# Mapa de Comunicação

Todos os tópicos MQTT, UUIDs BLE e contratos entre os três repositórios (app, esp32, orquestrador).

---

## 📋 Tópicos MQTT — Tabela Central

**Organização:** `robo/<setor>/<tipo>`

| Tópico | Direção | Origem | Destino | Payload | Notas |
|--------|---------|--------|---------|---------|-------|
| `robo/comando/entrada` | ← | serial_ingestor | roteador | JSON | Comandos do app |
| `robo/motores/velocidade` | ← | roteador | motores | `{linear, angular}` | Setpoint de velocidade |
| `robo/motores/parada` | ← | roteador | motores | `{}` | Parada de emergência |
| `robo/telemetria/motores` | → | motores | cloud/ingestor | `{posicao, vel_esq, vel_dir, ts}` | Posição e velocidades reais |
| `robo/telemetria/gps` | → | gps | cloud/ingestor | `{lat, lon, alt, speed, timestamp}` | Localização |
| `robo/telemetria/bateria` | → | telemetria | cloud/ingestor | `{tensao, corrente, percentual}` | Estado da bateria |
| `robo/telemetria/wifi` | → | wifi | cloud/ingestor | `{ssid, signal_strength, ip}` | Rede atual |
| `robo/wifi/comando` | ← | roteador | wifi | `{ssid, psk}` | Mudar rede |
| `robo/voz/comando` | ← | roteador | (future) | `{texto}` | Sintetizar voz (não impl.) |
| `robo/diagnostico/uptime` | → | main.py | cloud/ingestor | `{segundos, versao}` | Heartbeat |

**Fonte de verdade:** `orquestrador/pi/services/_common/src/robo_common/topics.py`

---

## 📱 UUIDs BLE — ESP32 ↔ App

Definição do serviço **Nordic UART Service** (padrão nRF):

| Nome | UUID | Quem define | Validação |
|------|------|-------------|-----------|
| **Serviço UART** | `6e400001-b5a3-f393-e0a9-e50e24dcca9e` | ESP32 | App deve conhecer |
| **RX (write char)** | `6e400002-b5a3-f393-e0a9-e50e24dcca9e` | ESP32 | App escreve para ESP32 |
| **TX (notify char)** | `6e400003-b5a3-f393-e0a9-e50e24dcca9e` | ESP32 | ESP32 notifica o app |

**Localização no App:**
```dart
// app/lib/services/robot_connection.dart
class RobotBleIds {
  static const String serviceUUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";
  static const String rxCharacteristicUUID = "6e400002-b5a3-f393-e0a9-e50e24dcca9e";
  static const String txCharacteristicUUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e";
}
```

**Localização no ESP32:**
```cpp
// esp32/esp32_ble_bridge/esp32.ino
#define SERVICE_UUID        "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
#define CHARACTERISTIC_UUID_RX "6e400002-b5a3-f393-e0a9-e50e24dcca9e"
#define CHARACTERISTIC_UUID_TX "6e400003-b5a3-f393-e0a9-e50e24dcca9e"
```

**Como validar:** Grep `6e400001` em ambos os repositórios. Se não bater, app não encontra o ESP32.

---

## 🔤 Formato de Comandos JSON

### Comandos de Movimento

**App → ESP32 (BLE) → Pi (UART)**

```json
{
  "cmd": "F"  // ou "R", "L", "D" (frente, ré, esquerda, direita)
}
```

| Comando | Efeito | Duração |
|---------|--------|---------|
| `"F"` | Frente | enquanto não houver "S" |
| `"R"` | Ré | enquanto não houver "S" |
| `"L"` | Esquerda (rotação) | enquanto não houver "S" |
| `"D"` | Direita (rotação) | enquanto não houver "S" |
| `"S"` | Stop (parada) | imediato |

**Como app envia:** Repete o comando a cada 300 ms enquanto o dedo está pressionado no botão.

**Como validar:** Grep `"cmd"` em `app/lib/` para ver que campos estão sendo enviados.

### Comandos de Voz (futuro)

```json
{
  "cmd": "voz",
  "texto": "Olá, estou vivo!"
}
```

### Parada de Emergência

```json
{
  "cmd": "emergencia"
}
```

Publicado por:
- App (botão de pânico)
- Motores (vigia, após 1s de silêncio)

---

## 🌐 Contrato MQTT — Qualidade de Serviço

| Aspecto | Valor | Motivo |
|---------|-------|--------|
| **QoS** | 1 (at-least-once) | Comando pode ser duplicado, mas não perdido |
| **Retain** | false (comandos) | Comandos antigos não devem reativar |
| **Retain** | true (telemetria) | Último valor fica visível para novos subscribers |
| **Keep-alive** | 60s | Broker desconecta se >60s sem ping |
| **Timeouts** | 5s (conectar), 10s (pub) | Defaults paho-mqtt |

---

## 🔌 Serial UART — ESP32 ↔ Raspberry Pi

| Parâmetro | Valor | Motivo |
|-----------|-------|--------|
| **Baudrate** | 115200 | Padrão Arduino/Serial |
| **Bits de dados** | 8 | Padrão |
| **Stop bits** | 1 | Padrão |
| **Paridade** | None | Padrão |
| **Terminador** | `\n` (0x0A) | JSON termina em newline |

**Exemplo de trama:**
```
$ hexdump -C /dev/ttyUSB0 (100ms)
00000000  7b 22 63 6d 64 22 3a 22  46 22 7d 0a 7b 22 63 6d  |{"cmd":"F"}{"cm|
00000010  64 22 3a 22 46 22 7d 0a                           |d":"F"}.|
```

Duas mensagens, cada uma + newline, a 300ms de intervalo (app enviando "F").

---

## 🔐 Autenticação & Autorização

### MQTT Local (Raspberry Pi)

```python
client = mqtt.Client(client_id="orquestrador")
# Sem autenticação: está na mesma LAN
client.connect("localhost", 1883)
```

### MQTT Remoto (Cloud)

```python
client.username_pw_set("robo_telemetria", password)
client.tls_set(ca_certs="ca.crt", certfile="client.crt", keyfile="client.key")
client.tls_insecure = False
client.connect("mqtt.cloud.example.com", 8883)  # TLS port
```

### HTTP API (Cloud)

**Com autenticação:**
```bash
curl -H "Authorization: Bearer TOKEN" \
  https://api.example.com/v1/telemetria/motores?from=2026-01-01&to=2026-01-02
```

**Sem autenticação (público):**
```bash
curl https://api.example.com/v1/publico/posicao  # Dados limitados
```

---

## 🚨 Estados de Falha & Recuperação

### BLE desconecta

```
App detecta desconexão → pausa de envios
ESP32 não recebe → não publica nada
Pi espera 1s → publica "parada" em motores
Motor para
```

### MQTT broker local cai

```
serial_ingestor não consegue publicar → log de erro
Motor para após 1s de vigia
Quando broker volta → resubscreve, volta ao normal
```

### API cloud indisponível

```
App não consegue fazer GET em /v1/telemetria → mostra "sem conexão"
Telemetria no Pi continua sendo publicada → buffer local cresce
Bridge MQTT sincroniza quando cloud volta
```

---

## 📝 Exemplo de Sessão Completa

### Setup inicial

1. Pi liga, serviços inicializam
2. ESP32 BLE escuta, App conecta
3. App faz GET em `/v1/diagnostico` → confirma que Pi está online
4. Interface mostra "Pronto"

### Usuário toca "Frente"

```
[App] 300ms loop:
  {"cmd":"F"} → BLE write
  
[ESP32]
  Recebe BLE → valida JSON → Serial.println
  
[Pi serial_ingestor]
  readline → MQTT publish("robo/comando/entrada")
  
[Pi roteador]
  onMessage("robo/comando/entrada") → dispatch ComandoMotor
  ComandoMotor.rotear() → publish("robo/motores/velocidade")
  
[Pi motores]
  onMessage("robo/motores/velocidade") → acionamento.aplicar(0.5, 0.5)
  Motor começa, rampa acelera em 500ms
  
[Pi motores — vigia]
  tick() a cada 50ms → rampa.atualizar(dt) → posicao_atual
  publish("robo/telemetria/motores")
  
[Cloud ingestor]
  onMessage("robo/telemetria/motores") → INSERT em TimescaleDB
  
[App — 2s depois, usuário solta]
  Para de enviar {"cmd":"F"}
  
[Pi motores — vigia]
  1s de silêncio → publish("robo/motores/parada")
  
[Pi motores]
  Recebe parada → acionamento.aplicar(0, 0)
  Rampa desacelera em 500ms → motor para suavemente
  
[Cloud]
  GET /v1/telemetria/motores?from=...&to=... → histórico disponível
```

---

## ✅ Checklist de Validação

Antes de mexer em qualquer tópico, comando ou UUID:

- [ ] Grep do novo nome em `topics.py`
- [ ] Verificar se app conhece o novo UUID (se for BLE)
- [ ] Verificar se serviço que publica está online
- [ ] Verificar se serviço que assina está subscrito
- [ ] Testar localmente sem cloud
- [ ] Testar com cloud (se houver)
- [ ] Atualizar este documento
- [ ] Atualizar CLAUDE.md

---

Veja também: [[./visao-geral.md]], [[./como-funciona.md]], [[../api/contrato-mqtt.md]]
