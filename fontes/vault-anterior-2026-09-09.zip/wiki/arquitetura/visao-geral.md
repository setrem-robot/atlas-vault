# Arquitetura — Visão Geral

## Diagrama Mental (Ponta a Ponta)

```
┌─────────────────────────────────────────────────────────────┐
│                        App Flutter                          │
│                   (iOS/Android + web)                       │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ BLE ↔ RobotBleIds (UUIDs Nordic UART) — 300 ms loop │   │
│  └──────────────────────────────────────────────────────┘   │
└────────────────┬─────────────────────────────────────────────┘
                 │
                 ↓ BLE Serial (JSON)
         ┌──────────────┐
         │   ESP32      │  ← C++/Arduino
         │  BLE Bridge  │  ← Bridge serial em JSON
         └──────────────┘
                 │
                 ↓ UART Serial
         ┌──────────────────────────────────────────┐
         │  Raspberry Pi (Serviços Python)          │
         ├─────────────────────────────────────────┤
         │ ┌────────────────────────────────────┐   │
         │ │ robo_common/                       │   │
         │ │ - topics.py (fonte de verdade MQTT)│   │
         │ │ - MqttService (paho client)        │   │
         │ └────────────────────────────────────┘   │
         │                                          │
         │ ┌─────────────────────────────────────┐  │
         │ │ serial_ingestor                     │  │
         │ │ Lê JSON do ESP32 → publica em MQTT  │  │
         │ └─────────────────────────────────────┘  │
         │                                          │
         │ ┌─────────────────────────────────────┐  │
         │ │ orquestrador (roteador)             │  │
         │ │ MQTT: robo/comando/* → processa    │  │
         │ │ Command Pattern (ABC + subclasses) │  │
         │ └─────────────────────────────────────┘  │
         │                                          │
         │ ┌─────────────────────────────────────┐  │
         │ │ motores (3 camadas)                 │  │
         │ │ 1. cinematica.py (puro)            │  │
         │ │ 2. acionamento.py (ABC, Stepper)   │  │
         │ │ 3. main.py (vigia de silêncio)     │  │
         │ │ Vigia: pare se >1s sem comando    │  │
         │ └─────────────────────────────────────┘  │
         │                                          │
         │ ┌─────────────────────────────────────┐  │
         │ │ gps                                 │  │
         │ │ Posicao (classe encapsulada)       │  │
         │ └─────────────────────────────────────┘  │
         │                                          │
         │ ┌─────────────────────────────────────┐  │
         │ │ wifi                                │  │
         │ │ rede.py (validação + nmcli)        │  │
         │ └─────────────────────────────────────┘  │
         └──────────────────────────────────────────┘
                 │
                 ↓ MQTT (local ou remoto)
         ┌──────────────────────────────┐
         │  Mosquitto (Broker)          │
         │  (local no Pi, também nuvem)  │
         └──────────────────────────────┘
                 │
                 ↓ TCP/IP
         ┌──────────────────────────────────────────┐
         │  Cloud — Docker Compose                  │
         │  ┌─────────────────────────────────────┐ │
         │  │ Mosquitto remoto                    │ │
         │  │ (bridge com Pi para duplex)         │ │
         │  └─────────────────────────────────────┘ │
         │  ┌─────────────────────────────────────┐ │
         │  │ ingestor (Python)                   │ │
         │  │ MQTT → TimescaleDB (insert-only)   │ │
         │  └─────────────────────────────────────┘ │
         │  ┌─────────────────────────────────────┐ │
         │  │ TimescaleDB (PostgreSQL + extens)  │ │
         │  │ Série temporal da telemetria       │ │
         │  └─────────────────────────────────────┘ │
         │  ┌─────────────────────────────────────┐ │
         │  │ api (FastAPI)                       │ │
         │  │ /v1/... (com token) + /v1/publico/ │ │
         │  │ SELECT-only (user=robo_leitura)   │ │
         │  └─────────────────────────────────────┘ │
         │  ┌─────────────────────────────────────┐ │
         │  │ cloudflared (Tunnel ingress)        │ │
         │  │ HTTPS → aplicativo fora da rede    │ │
         │  └─────────────────────────────────────┘ │
         └──────────────────────────────────────────┘
                 │
                 ↓ HTTPS (Internet pública)
         ┌──────────────────────────────────┐
         │  Landing page (Cloudflare Pages) │
         │  HTML/CSS/JS, consome API pub    │
         └──────────────────────────────────┘
```

---

## Os Três Repositórios

| Repo | Linguagem | Onde roda | O que faz |
|------|-----------|----------|-----------|
| **`esp32/esp32_ble_bridge`** | C++/Arduino | ESP32 | Lê JSON em UART, repassa por BLE. Sem lógica de negócio. |
| **`orquestrador`** | Python | Raspberry Pi + Cloud | Firmware dos serviços, API, ingestor, documentação. **Fonte de verdade.** |
| **`app`** | Dart/Flutter | iOS/Android/web | Interface do usuário. Conecta por BLE ao ESP32. |

### Dados de cada lado

- **App** → conhece os UUIDs BLE (`RobotBleIds`), nada mais.
- **ESP32** → conhece JSON e tópicos BLE/Serial, nada mais.
- **Pi/Cloud** → conhece MQTT, GPS, motores, banco de dados.

**O mapa de comunicação** (que UUIDs, que tópicos, que contratos) vive em **`orquestrador/MAPA-COMUNICACAO.md`** e **`robo_common/topics.py`** — juntos, no mesmo commit.

---

## Tecnologia Stack

### Backend (Raspberry Pi)

```
Linguagem: Python 3.x
Broker MQTT: paho-mqtt
Banco local: nenhum (estado volátil no Pi)
Scheduler: systemd (5 serviços)
Entrada: UART (serial_ingestor) + WiFi (wifi)
Saída: GPIO (motores), MQTT
Lógica: POO (ABC, herança, encapsulação)
```

### Cloud

```
Orquestrador: Docker Compose
Broker: Eclipse Mosquitto
Banco: PostgreSQL + TimescaleDB (série temporal)
API: FastAPI + httpx (cliente)
Network: Cloudflare Tunnel (ingress HTTPS)
Deploy: docker-compose up -d
```

### Frontend

```
Framework: Flutter (Dart)
Protocolos: BLE, HTTPS
Persistência: SharedPreferences (app Flutter)
Build targets: iOS, Android, web (via canvaskit)
```

### Firmware

```
Linguagem: C++/Arduino
IDE: Arduino IDE ou VSCode + PlatformIO
Protocolo: BLE (Nordic UART Service UUIDs)
Entrada: UART serial (JSON)
Saída: BLE serial (JSON)
```

---

## Decisões Chave

### 1. **BLE, não Bluetooth Classic**
- **Motivo:** iOS não oferece SPP (Bluetooth Classic) para apps de terceiros
- **Impacto:** Compatibilidade iOS + Android com mesma codebase
- **Validação:** UUIDs do ESP32 `esp32_ble_bridge/esp32.ino` **devem** bater com `app/lib/services/robot_connection.dart`

### 2. **Movimento repetido, silêncio é "pare"**
- **4 camadas independentes:**
  1. App repete a cada 300 ms enquanto dedo no botão
  2. ESP32 avisa ao perder BLE
  3. `motores/vigia.py` para se >1s sem comando
  4. RLock em `ServicoMotores` (exclusão mútua)
- **Motivo:** Falha de uma camada não deixa robô descontrolado

### 3. **API read-only com dois acessos**
- `/v1/...` exige `Authorization: Bearer`, serve tudo
- `/v1/publico/...` sem autenticação, serve menos (posição arredondada ~11m)
- **Motivo:** Evitar injeção SQL; API é a única peça exposta

### 4. **Motores: 3 camadas**
- `cinematica.py` — puro, testável sem hardware
- `acionamento.py` — ABC com `Stepper` e `Simulado`
- `main.py` — MQTT + vigia
- **Motivo:** Cada camada independente, sem acoplamento a GPIO

### 5. **Roteador: Command Pattern**
- `ComandoRoteavel` = ABC com subclasses (`ComandoMotor`, `ComandoVoz`, etc.)
- **Motivo:** Disposto polimórfico, sem dict de funções, extensível

---

## Comunicação: Tópicos MQTT

**Organização:** `robo/<setor>/<assunto>`

- `robo/telemetria/...` ← GPS, bateria, sensores
- `robo/motores/...` ← velocidade, posição
- `robo/comando/...` → direção, voz, emergência
- `robo/wifi/...` → SSID, senha
- `robo/diagnostico/...` ← uptime, versão

**Fonte de verdade:** `orquestrador/pi/services/_common/src/robo_common/topics.py`

**Como validar:** Antes de mexer em um tópico, grep em `topics.py` e em `MAPA-COMUNICACAO.md`.

---

## Segurança

### Em movimento
- **Repetição obrigatória:** App deve reenviar comando a cada 300 ms
- **Timeout:** Motores param se não receberem nada em 1 s
- **Observador de thread:** RLock evita race condition entre MQTT e vigia

### No banco
- **Read-only:** API conecta como `robo_leitura`, sem INSERT/DELETE
- **Ingestão separada:** Só `ingestor` pode escrever (via user `robo_ingestor`)
- **Auditoria:** TimescaleDB guarda tudo (append-only)

### Na rede
- **Local:** MQTT sem autenticação (está na mesma LAN do Pi)
- **Remoto:** Mosquitto usa TLS + credenciais
- **API:** Bearer token obrigatório, HTTPS (via Cloudflare)
- **Público:** `/v1/publico/` sem token, dados limitados

---

## Estados Representativos

### Setup Mínimo (prototipagem)
```
ESP32 (BLE) ← App Flutter
     ↓ Serial
Raspberry Pi (serviços em MQTT local)
```
Sem cloud, sem database. Motores e GPS locais.

### Setup Completo (atual)
```
App Flutter ← BLE ← ESP32 ← UART ← Raspberry Pi
                                     ↓ MQTT bridge
                              Cloud (Mosquitto + API)
```
Telemetria chega na nuvem, app pode consultar histórico via HTTPS.

### Setup Descentralizado (futuro?)
```
Vários robôs → Broker central → API → Web dashboard
```
Controle de múltiplos robôs, compartilhamento de dados.

---

## Próximos Passos Arquiteturais

1. **Unificar `_parar`/`_tratar_sinal`** nos 5 `main.py` (duplicado)
2. **Dar classes a `wifi/rede.py`** (hoje é dict + funções)
3. **Generalizar `Posicao` de GPS** para um sensor abstrato
4. **Adicionar `IoC` ou dependency injection** (opcional, hoje está ok)

---

Veja também: [[../modulos/index.md]], [[./como-funciona.md]], [[./mapa-comunicacao.md]]
