# Como Funciona — Ponta a Ponta

Este documento segue um comando/telemetria desde o toque do dedo até o motor, e de volta.

---

## Comando: Do Dedo até o Motor

### 1️⃣ Usuário toca "Frente" no App Flutter

```dart
// app/lib/services/robot_connection.dart
// Evento BLE: RobotBleIds.writeChar (Nordic UART TX)
_sendCommand({"cmd": "F"});  // F = frente, R = ré, L = esquerda, D = direita
```

**O que acontece:**
- App escreve JSON em UTF-8 + newline: `{"cmd":"F"}\n`
- Gráfico Bluetooth é aberto cada 300 ms enquanto o dedo está pressionado (loop)
- Se soltar o dedo: para de enviar. Silêncio.

---

### 2️⃣ ESP32 recebe pela BLE e repassa ao Pi

```cpp
// esp32/esp32_ble_bridge/esp32.ino
// Nordic UART Service RX callback
if (rxMessage received) {
    if (isValidJSON(rxMessage)) {
        Serial.println(rxMessage);  // Repassa para o Pi
    }
}
```

**O que acontece:**
- ESP32 é **apenas uma ponte**: não interpreta `{"cmd":"F"}`, só valida JSON
- Repassa idêntico para UART serial (Pi ouve em `/dev/ttyUSB0` ou similar)
- Se a BLE morrer enquanto o comando estava no ar: o JSON não chega no Pi

---

### 3️⃣ Raspberry Pi — serial_ingestor lê a Serial

```python
# orquestrador/pi/services/serial_ingestor/main.py
while True:
    line = serial_port.readline()  # Bloqueia até \n
    try:
        msg = json.loads(line)
        if "cmd" in msg:
            client.publish("robo/comando/entrada", json.dumps(msg))
    except json.JSONDecodeError:
        logger.error("JSON inválido")
```

**O que acontece:**
- serial_ingestor ouve a porta serial e publica em `robo/comando/entrada`
- Mensagem MQTT chega em quem estiver escutando

---

### 4️⃣ Orquestrador roteador despacha o comando

```python
# orquestrador/pi/services/orquestrador/src/orquestrador/roteador.py
def on_message(client, userdata, msg):
    if msg.topic == "robo/comando/entrada":
        payload = json.loads(msg.payload)
        comando_tipo = payload.get("cmd")
        # Command Pattern: dispatch polimórfico
        if comando_tipo in _ROTAS:
            _ROTAS[comando_tipo].rotear(payload)
```

**O que acontece:**
- Roteador busca a classe responsável pela rota `cmd=F`
- Chama `ComandoMotor("F").rotear(payload)`
- ComandoMotor publica em `robo/motores/velocidade`:
  ```json
  {"linear": 0.5, "angular": 0, "lado_esquerdo": 0.5, "lado_direito": 0.5}
  ```

---

### 5️⃣ Serviço motores recebe o comando

```python
# orquestrador/pi/services/motores/main.py
def on_message(client, userdata, msg):
    if msg.topic == "robo/motores/velocidade":
        vel = json.loads(msg.payload)
        with lock:  # RLock: exclusão mútua
            acionamento.aplicar(vel["lado_esquerdo"], vel["lado_direito"])
```

**O que acontece:**
- Dentro de um RLock (reentrante)
- Chama `acionamento.aplicar()`, que despacha para o backend concreto

---

### 6️⃣ Acionamento: Simulado ou Real

#### Modo Simulado (dev no notebook)
```python
# orquestrador/pi/services/motores/src/motores/acionamento.py
class AcionamentoSimulado(Acionamento):
    def aplicar(self, esq, dir):
        logger.info(f"[SIM] Motor esq={esq}, dir={dir}")
        # Nada de verdade acontece
```

#### Modo Real (Raspberry Pi com steppers)
```python
class AcionamentoStepper(Acionamento):
    def aplicar(self, esq, dir):
        freq_esq = int(abs(esq) * 5000)  # 5000 Hz max
        freq_dir = int(abs(dir) * 5000)
        
        pwm_esq.frequency = freq_esq
        pwm_dir.frequency = freq_dir
        
        gpio_dir_esq.value = 1 if esq >= 0 else 0
        gpio_dir_dir.value = 1 if dir >= 0 else 0
        
        pwm_esq.start(100)  # 100% duty cycle
        pwm_dir.start(100)
```

**O que acontece:**
- GPIO recebe PWM (onda quadrada) do frequência = velocidade
- Driver TMC2209 recebe STEP + DIR
- Motor move

---

## Telemetria: Do Motor até o App

### 1️⃣ Serviço motores publica estado

```python
# orquestrador/pi/services/motores/main.py
def tick():
    with lock:
        rampa.atualizar(dt)  # Acelera suavemente
        posicao_atual = acionamento.posicao()
        
    client.publish("robo/telemetria/motores", json.dumps({
        "posicao": posicao_atual,
        "velocidade_esq": rampa.vel_esq,
        "velocidade_dir": rampa.vel_dir,
        "timestamp": time.time()
    }))
```

---

### 2️⃣ Cloud ingestor recebe e escreve no banco

```python
# orquestrador/cloud/ingestor/main.py
def on_message(client, userdata, msg):
    if "telemetria" in msg.topic:
        data = json.loads(msg.payload)
        cur.execute("""
            INSERT INTO telemetria_motores (tempo, posicao, velocidade_esq, velocidade_dir)
            VALUES (%s, %s, %s, %s)
        """, (data["timestamp"], data["posicao"], data["velocidade_esq"], data["velocidade_dir"]))
        conn.commit()
```

---

### 3️⃣ App consulta a API

```dart
// app/lib/services/api_client.dart
Future<List<MotorData>> getHistorico({
    required String token,
    required DateTime from,
    required DateTime to
}) async {
    final response = await http.get(
        Uri.parse("https://atlas.example.com/v1/motores?from=$from&to=$to"),
        headers: {"Authorization": "Bearer $token"}
    );
    if (response.statusCode == 200) {
        return MotorData.fromJsonList(jsonDecode(response.body));
    }
}
```

---

## Exemplo Concreto: "Frente por 2 segundos"

| Tempo | Evento | Estado |
|------|--------|--------|
| t=0 | Usuário toca "Frente" | App começa a enviar `{"cmd":"F"}` a cada 300ms |
| t=+10ms | ESP32 recebe BLE | Repassa para UART |
| t=+50ms | Pi lê serial | serial_ingestor publica em `robo/comando/entrada` |
| t=+60ms | Roteador despacha | Publica em `robo/motores/velocidade` |
| t=+80ms | Motores recebem | Acionamento aplica PWM, motor começa |
| t=0.1s | Motor acelera | Rampa vai de 0 até 0.5 suavemente |
| t=0.5s | Telemetria | Motor publica `robo/telemetria/motores` |
| t=0.55s | Cloud recebe | Ingestor escreve em TimescaleDB |
| t=1.0s | Motor em velocidade | Rampa estabilizou |
| t=2.0s | Usuário solta dedo | App para de enviar |
| t=2.0s | Silêncio começa | Vigia em motores conta 1 segundo |
| t=2.05s | Roteador publica parada | `{"cmd":"S"}` é enviado (pause) |
| t=2.1s | Motores recebem parada | Acionamento aplica 0 velocidade |
| t=2.15s | Motor desacelera | Rampa vai até 0 suavemente |
| t=2.3s | Motor parado | Vigia reset para 0s, motor inerte |

---

## Os 3 Responsáveis de "Pare"

1. **App**: para de enviar comandos de frente → silêncio
2. **ESP32**: avisa ao Pi quando BLE desconecta
3. **Motores vigia**: conta segundos de silêncio, publica `S` ("stop") após 1s
4. **RLock**: garante que ninguém escreve no GPIO no meio de um `aplicar()`

**Se (1) falhar:** ESP32 avisa. Se (2) falhar: vigia ativa. Se (3) falhar: RLock impede race.

---

## Exceções e Recuperação

### Conexão BLE morre no meio

```
App está enviando "F"...
    ↓
BLE desconecta (usuário se afasta, wi-fi interfere, etc)
    ↓
ESP32 note a desconexão
    ↓
[Opcional: ESP32 envia "desconectado" ao Pi?]
    ↓
1 segundo se passa sem comando
    ↓
Motores vigia publica "S" (parada de segurança)
    ↓
Motor para suavemente (rampa de desaceleração)
```

### MQTT broker cai

```
App → ESP32 → UART → serial_ingestor → MQTT Mosquitto (cai aqui)
                                           ↑
                                    roteador não recebe
                                    motores não recebem
                                    motor para após 1s (vigia)
                                    
Quando broker volta:
    - App reconecta, pode enviar novos comandos
    - Histórico no banco permanece intacto
    - Nenhuma telemetria foi perdida em cloud (estava no Pi, vai chegar)
```

### Raspberry Pi perde conexão com cloud

```
Mosquitto local no Pi continua rodando.
Telemetria continua sendo publicada localmente.
Bridge MQTT (Pi → cloud) tenta reconectar.
Quando cloud volta:
    - Bridge sincroniza (replay de buffer local)
    - Dados chegam ao bank de forma ordenada (timestamp)
    - App pode consultar histórico sem perda
```

---

## Cinética & Rampa de Aceleração

```python
# cinematica.py — movimento puro
class Rampa:
    def __init__(self, duracao=0.5):
        self.duracao = duracao  # 500ms para acelerar de 0 → vmax
        self.vel_atual = 0.0
    
    def atualizar(self, vel_alvo, dt):
        """Aproxima vel_atual de vel_alvo suavemente."""
        delta = vel_alvo - self.vel_atual
        max_delta = (vmax / self.duracao) * dt
        
        if abs(delta) <= max_delta:
            self.vel_atual = vel_alvo
        else:
            self.vel_atual += max_delta * sign(delta)
```

**Efeito:** Motor não sai de 0 para vmax instantaneamente; acelera em 500ms.

**Vantagem:** Evita tremor mecânico, corrente de pico no motor, desgaste.

---

Veja também: [[./visao-geral.md]], [[./mapa-comunicacao.md]], [[../modulos/motores.md]]
