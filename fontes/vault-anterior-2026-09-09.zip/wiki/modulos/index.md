# Módulos — Índice

Documentação completa de cada componente do SetremBot: firmware, serviços, API, app.

---

## 🔧 Firmware ESP32

**Arquivo:** [`esp32/esp32_ble_bridge/esp32.ino`](../../orquestrador/esp32/esp32_ble_bridge/)

**Linguagem:** C++/Arduino

**Responsabilidade:** Bridge serial ↔ BLE

| Aspecto | Detalhe |
|---------|---------|
| **MCU** | ESP32 (com BLE dual-mode) |
| **Protocolo BLE** | Nordic UART Service (padrão nRF) |
| **Entrada** | UART serial de um meio externo (de quê?) |
| **Saída** | BLE notify (app Flutter lê) |
| **Validação** | JSON parsing, sem lógica de negócio |
| **Taxa** | 115200 baud serial, BLE MTU 23 bytes |

**Testes:** Compilar com PlatformIO, testar com Serial Monitor.

**Documentação:** [[./esp32.md]]

---

## 🐍 Serviços Python (Raspberry Pi)

**Arquivo:** [`orquestrador/pi/services/`](../../orquestrador/pi/services/)

**Linguagem:** Python 3.x

**Runtime:** systemd (5 serviços independentes, venv compartilhado)

### Estrutura em árvore

```
pi/services/
├── _common/                      — Biblioteca compartilhada
│   └── src/robo_common/
│       ├── topics.py              ← Fonte de verdade MQTT
│       ├── mqtt_client.py         ← MqttService (ABC)
│       └── contratos.py           ← Validação de dados
│
├── serial_ingestor/               ← Lê UART → publica MQTT
│   ├── main.py
│   ├── pyproject.toml
│   └── tests/
│
├── orquestrador/                  ← Roteador (Command Pattern)
│   ├── src/orquestrador/roteador.py
│   ├── main.py
│   ├── pyproject.toml
│   └── tests/test_roteador.py (30 cases)
│
├── motores/                       ← 3 camadas
│   ├── src/motores/
│   │   ├── cinematica.py          ← Puro (testável)
│   │   ├── acionamento.py         ← ABC (Stepper/Simulado)
│   │   └── vigia.py               ← Silêncio → parada
│   ├── main.py
│   ├── pyproject.toml
│   └── tests/ (52 cases)
│
├── gps/                           ← Localização
│   ├── main.py
│   ├── posicao.py                 ← Classe encapsulada
│   └── tests/
│
├── wifi/                          ← Gerenciador de rede
│   ├── main.py
│   ├── rede.py                    ← nmcli wrapper
│   ├── pyproject.toml
│   └── tests/ (16 cases)
│
└── scripts/
    └── install.sh                 ← Setup venv + systemd
```

### Resumo de cada serviço

| Serviço | Entrada | Saída | Lógica | Testes |
|---------|---------|-------|--------|--------|
| **serial_ingestor** | UART `/dev/ttyUSB0` | MQTT `robo/comando/*` | JSON parsing | nenhum (hardware) |
| **orquestrador** | MQTT `robo/comando/*` | MQTT `robo/motores/*` | Command Pattern | 30 (unittest, sem MQTT) |
| **motores** | MQTT `robo/motores/*` | GPIO (PWM + DIR) | Cinemática + controle | 52 (3 camadas) |
| **gps** | Serial `/dev/ttyUSB1` | MQTT `robo/telemetria/gps` | GPS parsing | nenhum (hardware) |
| **wifi** | MQTT `robo/wifi/comando` | nmcli + NM service | Rede WiFi | 16 (mock nmcli) |

### Instalação

```bash
cd orquestrador/pi/services
bash scripts/install.sh
# Cria venv, instala dependências, habilita 5 serviços systemd
sudo systemctl status robo-serial-ingestor
sudo systemctl status robo-orquestrador
sudo systemctl status robo-motores
sudo systemctl status robo-gps
sudo systemctl status robo-wifi
```

**Documentação:** [[./python-services.md]]

---

## ☁️ Cloud — Docker Compose

**Arquivo:** [`orquestrador/cloud/`](../../orquestrador/cloud/)

**Linguagem:** Python (ingestor + API), SQL (TimescaleDB), Shell (Dockerfile)

**Deployment:** Docker Compose (5 containers)

| Container | Imagem | Porta | O que faz |
|-----------|--------|-------|----------|
| **mosquitto** | eclipse-mosquitto:latest | 8883 (TLS) | Broker MQTT remoto |
| **ingestor** | python:3.11 | - | MQTT → TimescaleDB |
| **timescaledb** | timescaledb/timescaledb:latest | 5432 | Banco série temporal |
| **api** | python:3.11 | 8000 | FastAPI, SELECT-only |
| **cloudflared** | cloudflare/cloudflared:latest | - | HTTPS tunnel |

### Ingestor

```python
# cloud/ingestor/main.py
class Ingestor:
    def __init__(self, mqtt_broker, db_conn):
        self.mqtt = MqttService(broker)
        self.db = db_conn
    
    def on_telemetria(self, msg):
        data = json.loads(msg.payload)
        self.db.insert("telemetria", data)  # INSERT-only
```

### API FastAPI

**Portas:**
- `/v1/...` — requer Bearer token, dados completos
- `/v1/publico/...` — sem token, dados limitados

**Exemplos:**
```bash
# Privada
GET /v1/telemetria/motores?from=2026-01-01&to=2026-01-02 \
  -H "Authorization: Bearer TOKEN"

# Pública
GET /v1/publico/posicao  # Retorna última posição (arredondada)
```

**Documentação:** [[./api-cloud.md]]

---

## 📱 App Flutter

**Arquivo:** [`app/lib/`](../../app/lib/)

**Linguagem:** Dart

**Plataformas:** iOS, Android, web

### Estrutura

```
lib/
├── main.dart                      ← Entry point
├── screens/
│   ├── home_screen.dart           ← Dashboard
│   ├── control_screen.dart        ← Botões de controle
│   └── history_screen.dart        ← Gráficos do histórico
│
├── services/
│   ├── robot_connection.dart      ← BLE client
│   ├── robot_ble_ids.dart         ← UUIDs (RobotBleIds)
│   └── api_client.dart            ← HTTP + auth
│
└── models/
    ├── robot_command.dart
    ├── telemetry.dart
    └── history.dart
```

### Fluxo BLE

```dart
// Conectar ao ESP32
await characteristic.write(utf8.encode('{"cmd":"F"}\n'), withoutResponse: false);

// Receber telemetria (future)
characteristic.value.listen((data) {
    String msg = utf8.decode(data);
    // Processar
});
```

### Ciclo de comando

```dart
void _onDirectionPressed(String direction) {
    // Inicia loop
    _commandTimer = Timer.periodic(Duration(milliseconds: 300), (_) {
        _sendCommand({"cmd": direction});
    });
}

void _onDirectionReleased() {
    // Para o loop
    _commandTimer?.cancel();
    _sendCommand({"cmd": "S"});  // Parada
}
```

**Documentação:** [[./flutter-app.md]]

---

## 🔗 Dependências Cruzadas

```
app (Flutter)
    ↓ BLE (Nokia UART UUIDs)
    ↓ HTTP (Bearer token)
esp32_ble_bridge
    ↓ UART JSON
orquestrador (Python)
    ├─ serial_ingestor → MQTT
    ├─ roteador → motores
    ├─ motores → GPIO
    ├─ gps → telemetria
    └─ wifi → nmcli
    
    ↓ MQTT bridge
    
cloud (Docker)
    ├─ ingestor → TimescaleDB
    ├─ api → SELECT queries
    └─ cloudflared → HTTPS tunnel
    
    ↑ HTTPS
    
app (Flutter)
    ├─ GET /v1/telemetria
    └─ GET /v1/publico/posicao
```

---

Veja também: [[../arquitetura/visao-geral.md]], [[../configuracao/setup-completo.md]]
