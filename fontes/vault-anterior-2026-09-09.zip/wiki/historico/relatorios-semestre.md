# Histórico & Relatórios do Semestre

Resumo dos relatórios do semestre anterior (EstruturaPDF, InterfacePDF, OrquestradorPDF) e mudanças de arquitetura até agora.

---

## 📄 Relatórios Disponíveis

Todos em `/d/SetremRobot/Relatorios/`:

| Arquivo | Páginas | Foco | Atualização |
|---------|---------|------|------------|
| **EstruturaPDF.pdf** | ~60 | Especificação de hardware, diagrama, componentes | Até semestre anterior |
| **InterfacePDF.pdf** | ~150 | App Flutter, UI, fluxos, código-fonte | Até semestre anterior |
| **OrquestradorPDF.pdf** | ~70 | Serviços Python, MQTT, arquitetura | Até semestre anterior |

---

## 🔄 Mudanças Significativas Desde Relatórios

### ✅ Implementado

#### 1. BLE em vez de Bluetooth Classic

**Então (relatório):** SPP (Bluetooth Classic) era o transporte padrão.

**Agora:** Nordic UART Service (BLE).

**Motivo:** iOS não oferece SPP para apps de terceiros.

**Impacto:** UUIDs mudaram. Ver [[../../orquestrador/esp32/esp32_ble_bridge/esp32.ino]] e `RobotBleIds` em app.

**Validação:** Requer sincronização entre ESP32 e app. Grep `6e400001` em ambos.

#### 2. Vigia de Silêncio (Motores)

**Então:** Se BLE morreria, motor continuava andando (unsafe).

**Agora:** Camada independente em `motores/vigia.py` que para motor após 1s sem comando.

**Impacto:** 4 camadas de segurança independentes (app repeat, BLE notify, vigia timeout, RLock).

**Código:** [[../seguranca/index.md#camada-3-motores--vigia-de-silêncio]]

#### 3. Separação de Repositórios

**Então:** Tudo possivelmente integrado.

**Agora:** `app`, `esp32`, `orquestrador` são repos separados + git.

**Motivo:** Versionamento, CI/CD, equipas independentes.

**Impacto:** Mapa de comunicação deve estar **versionado** junto com o código (`MAPA-COMUNICACAO.md` no orquestrador).

#### 4. Cloud com TimescaleDB + FastAPI

**Então:** Possível que não houvesse histórico remoto.

**Agora:** Ingestor MQTT → TimescaleDB (série temporal) + API FastAPI (read-only).

**Impacto:** Telemetria persiste, app pode consultar histórico via HTTPS.

**Validação:** Ver `cloud/docker-compose.yml` e rotas em `cloud/api/main.py`.

#### 5. Roteador com Command Pattern

**Então:** Possível que fossem dict de funções ou if/elif.

**Agora:** `ComandoRoteavel` = ABC com subclasses (POO).

**Motivo:** Disciplina do usuário (faculdade = educação). Extensível, testável.

**Código:** `orquestrador/pi/services/orquestrador/src/orquestrador/roteador.py`

**Testes:** 30 casos em `test_roteador.py` (sem MQTT, sem hardware).

#### 6. Motores: 3 Camadas

**Então:** Possivelmente monolítico.

**Agora:**
- `cinematica.py` — lógica pura (testável em notebook)
- `acionamento.py` — ABC com `Stepper` e `Simulado`
- `main.py` — MQTT + vigia

**Motivo:** Cada peça independente, testável sem hardware.

**Testes:** 52 casos totais (sem Pi, sem motor, sem broker).

### 🚀 Em Andamento

- **Unificar `_parar`/`_tratar_sinal`** nos 5 `main.py` (duplicado)
- **Dar classes a `wifi/rede.py`** (hoje dict + funções)
- **Dashboard de telemetria** (web, gráficos em tempo real)
- **Autenticação/autorização** (JWT tokens, RBAC)

### 📋 Pendências Conhecidas

1. **serial_ingestor** — sem testes (precisa de hardware UART)
2. **GPS** — sem testes locais (precisa de GPS real)
3. **WiFi** — testes precisam de mock melhor de `nmcli`
4. **Documentação em IA** — relatorios em PDF, docs.md são mais novos
5. **CI/CD** — não há GitHub Actions configurado

---

## 📊 Métrica de Testes

| Componente | Testes | Coverage | Hardware |
|-----------|--------|----------|----------|
| `cinematica.py` | 20 | 100% | ❌ Não |
| `acionamento.py` | 15 | 85% | ⚠️ Mock |
| `vigia.py` | 12 | 100% | ❌ Não |
| `roteador.py` | 30 | 90% | ❌ Não |
| `wifi/rede.py` | 16 | 80% | ⚠️ Mock |
| **Total** | **93** | **~90%** | - |

**Serial_ingestor:** 0 testes (precisa UART real ou serial mock).
**GPS:** 0 testes (precisa GPS real ou mock de GPS).

---

## 🔄 Fluxo de Trabalho Atual

```
Relatórios (semestre N-1)
    ↓
Entendimento de requisitos
    ↓
Código-fonte atual (semestre N)
    ├─ esp32/ (BLE bridge)
    ├─ app/ (Flutter)
    └─ orquestrador/ (Python services)
    ↓
Testes (93 casos, ~90% coverage)
    ↓
Deploy Local (Pi + Cloud Docker)
    ↓
Telemetria chega na nuvem
    ↓
API retorna dados
    ↓
App consome e mostra
```

---

## 🎯 Objetivos para o Próximo Semestre

1. **CI/CD:** GitHub Actions para testar automaticamente
2. **Cobertura de testes:** 95%+ (incluindo serial_ingestor, gps)
3. **Dashboard:** Painel web para ver telemetria em tempo real
4. **Docs:** Este vault + vídeos de setup
5. **Performance:** Otimizar latência de comando (target: <100ms)
6. **Escalabilidade:** Suportar múltiplos robôs
7. **Segurança:** Audit de código, testes de penetração

---

## 📚 Como Usar Este Vault para Documentação

1. **Entender a arquitetura:** [[../arquitetura/visao-geral.md]]
2. **Entender o fluxo:** [[../arquitetura/como-funciona.md]]
3. **Integrar nova feature:** [[../arquitetura/mapa-comunicacao.md]] + [[../api/contrato-mqtt.md]]
4. **Setup para dev:** [[../configuracao/setup-completo.md]]
5. **Entender segurança:** [[../seguranca/index.md]]
6. **Explorar código:** [[../modulos/index.md]]
7. **Especificações de hw:** [[../hardware/especificacoes.md]]

---

## 🔗 Links dos PDFs Originais

- **Estrutura:** `file:///d/SetremRobot/Relatorios/EstruturaPDF.pdf`
- **Interface:** `file:///d/SetremRobot/Relatorios/InterfacePDF.pdf`
- **Orquestrador:** `file:///d/SetremRobot/Relatorios/OrquestradorPDF.pdf`

---

## 💡 Notas para Futuras Gerações

- **Este vault é "single source of truth"** — mantenha sincronizado com código
- **Tudo em git:** Commits atomizados, history é legível
- **Tests primeiro:** Novos testes para nova feature, depois código
- **Segurança é prioridade:** 4 camadas de motor-safety, RLock, read-only API
- **Educação:** Projeto é para alunos aprenderem — código bem estruturado, bem testado, bem documentado
- **Offline-first:** Vault em Markdown + git, não depende de nuvem

---

Veja também: [[../index.md]], [[../arquitetura/visao-geral.md]]
