# Segurança — Visão Completa

Estratégias de segurança em movimento, concorrência, rede e banco de dados.

---

## 🚨 Segurança em Movimento — 4 Camadas Independentes

### Camada 1: App Flutter — Repetição Obrigatória

```dart
void _onDirectionPressed(String direction) {
    _commandTimer = Timer.periodic(Duration(milliseconds: 300), (_) {
        _sendCommand({"cmd": direction});  // Repete a cada 300ms
    });
}

void _onDirectionReleased() {
    _commandTimer?.cancel();  // Para quando dedo levanta
    _sendCommand({"cmd": "S"});  // Envia parada explícita
}
```

**Garantia:** Enquanto o dedo está pressionado, comando é reenviad. Quando solta, para imediatamente.

**Falha se:** App trava ou conexão BLE cai enquanto dedo está pressionado.
**Coberto por:** Camadas 2, 3 e 4.

---

### Camada 2: ESP32 — Observador de BLE

```cpp
// esp32/esp32_ble_bridge/esp32.ino
void onConnect(BLEServer* pServer) {
    connected = true;
}

void onDisconnect(BLEServer* pServer) {
    connected = false;
    Serial.println("{\"alert\":\"ble_disconnected\"}");  // Opcional
}

void loop() {
    if (!connected && wasConnected) {
        // Sinalisar ao Pi que BLE morreu
        Serial.println("{\"alert\":\"ble_down\"}");
    }
    wasConnected = connected;
}
```

**Garantia:** Se BLE desconecta, ESP32 pode avisar ao Pi (ou ao menos para de repassar comandos).

**Falha se:** ESP32 também trava ou reseta.
**Coberto por:** Camada 3.

---

### Camada 3: Motores — Vigia de Silêncio

```python
# orquestrador/pi/services/motores/src/motores/vigia.py
class Vigia:
    def __init__(self, timeout_s=1.0):
        self.timeout = timeout_s
        self.ultimo_comando = time.time()
    
    def receber_comando(self, comando):
        self.ultimo_comando = time.time()
        # Processa
    
    def tick(self, agora):
        if agora - self.ultimo_comando > self.timeout:
            # 1 segundo de silêncio → parada
            return True  # Sinalizador de parada
        return False
```

**Integração em `main.py`:**
```python
def loop():
    while True:
        agora = time.time()
        
        # Escuta MQTT
        for msg in mqtt_recv():
            if msg.topic == "robo/motores/velocidade":
                vigia.receber_comando(msg)
        
        # Vigia tick
        if vigia.tick(agora):
            motor.parar()
            mqtt.publish("robo/motores/parada")
        
        sleep(0.05)  # 50ms
```

**Garantia:** Se nenhum comando chega em 1 segundo, motor para automaticamente.

**Falha se:** Pi trava ou o laço de `main()` ficar preso (improvável, é blocking I/O).
**Coberto por:** Camada 4.

---

### Camada 4: Exclusão Mútua (RLock)

```python
# orquestrador/pi/services/motores/main.py
class ServicoMotores:
    def __init__(self):
        self.lock = RLock()  # Reentrante
        self.acionamento = AcionamentoStepper()
        self.vigia = Vigia()
    
    def on_message(self, client, userdata, msg):
        """Roda na thread de rede do paho."""
        with self.lock:  # TRANCA
            payload = json.loads(msg.payload)
            self.acionamento.aplicar(payload["esq"], payload["dir"])
            self.vigia.receber_comando(msg)
    
    def tick(self):
        """Roda no laço principal."""
        with self.lock:  # TRANCA
            if self.vigia.tick(time.time()):
                self.acionamento.parar()
            
            # Atualiza rampa de aceleração
            self.acionamento.rampa.atualizar(dt=0.05)
```

**Garantia:** `on_message` (thread de rede) e `tick` (main loop) nunca executam simultaneamente na mesma região crítica. Um `aplicar()` que está em andamento não pode ser interrompido.

**Teste:**
```python
# motores/tests/test_concorrencia.py
def test_sem_race_condition():
    """Verifica que parada emergencial não sofre race com tick()."""
    s = ServicoMotores()
    
    # Simula tick() + on_message() concorrentes
    t1 = Thread(target=s.tick)
    t2 = Thread(target=s.on_message, args=(..., {"esq": 0.5, "dir": 0.5}))
    
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    
    # Valida que GPIO nunca recebeu comando mal-formado
    assert all(cmd.isvalid() for cmd in acionamento.historico)
```

---

## 🔒 Segurança de Banco de Dados

### Usuário de Leitura (robo_leitura)

```sql
CREATE USER robo_leitura WITH PASSWORD 'senha';
GRANT SELECT ON ALL TABLES IN SCHEMA public TO robo_leitura;
```

**Quem usa:** API FastAPI (container `api`)

**Permissões:**
```sql
SELECT * FROM telemetria_motores WHERE tempo > '2026-01-01';  ✅ OK
UPDATE telemetria_motores SET posicao = 0;                    ❌ PERMISSÃO NEGADA
DELETE FROM telemetria_motores;                               ❌ PERMISSÃO NEGADA
```

**Vantagem:** Bug na rota não consegue apagar 6 meses de dados.

### Usuário de Ingestão (robo_ingestor)

```sql
CREATE USER robo_ingestor WITH PASSWORD 'senha';
GRANT INSERT ON telemetria_motores, telemetria_gps, ... TO robo_ingestor;
GRANT SELECT ON all_tables TO robo_ingestor;  -- Lê para validar
```

**Quem usa:** Container `ingestor`

**Permissões:**
```sql
INSERT INTO telemetria_motores VALUES (...);  ✅ OK
UPDATE ...;                                   ❌ PERMISSÃO NEGADA
DELETE ...;                                   ❌ PERMISSÃO NEGADA
```

---

## 🛡️ Segurança de Rede

### MQTT Local (Raspberry Pi)

```
LAN privada (10.0.0.0/24 ou similar)
    ↓
Pi é host local (192.168.x.x)
    ↓
Mosquitto em localhost:1883 (sem TLS)
    ↓
Serviços só na mesma máquina conseguem se conectar
```

**Risco:** Alguém na mesma rede WiFi consegue enviar comandos.
**Mitigação:** Usar um SSID com WPA2/WPA3, segredo de rede.

### MQTT Remoto (Cloud)

```python
client.username_pw_set("robo_telemetria", "senha_forte")
client.tls_set(
    ca_certs="/etc/ssl/certs/ca-certificates.crt",
    certfile="/etc/certs/client.crt",
    keyfile="/etc/certs/client.key"
)
client.connect("mqtt.cloud.example.com", 8883)  # TLS port
```

**Garantias:**
- ✅ Autenticação por usuário + senha
- ✅ Criptografia TLS
- ✅ Validação de certificado CA
- ✅ Mutual TLS (client cert)

### HTTP API (FastAPI)

```python
# cloud/api/main.py
@app.get("/v1/telemetria/motores")
async def get_telemetria(
    from_: datetime,
    to: datetime,
    authorization: str = Header(...)
) -> dict:
    token = authorization.replace("Bearer ", "")
    if not validar_token(token):
        raise HTTPException(401, "Não autorizado")
    
    return db.query(telemetria_motores, from_, to)
```

**Token:**
- Gerado quando usuário faz login
- Expiração (ex: 24h)
- Revogável (blacklist)

**Rota pública:**
```python
@app.get("/v1/publico/posicao")
async def get_posicao_publica() -> dict:
    # Sem requerimento de token
    # Retorna posição arredondada (~11m) para privacidade
    lat, lon = db.ultima_posicao()
    return {
        "lat": round(lat, 4),   # ~11m de precisão
        "lon": round(lon, 4),
        "timestamp": db.timestamp_posicao()
    }
```

---

## 🔍 Validação de Entrada

### JSON no App → ESP32

```dart
// Antes de enviar
String command = jsonEncode({"cmd": "F"});
if (command.length > 100) {
    throw Exception("Comando muito longo");
}
```

### JSON no UART → serial_ingestor

```python
try:
    msg = json.loads(line)
    if "cmd" not in msg:
        raise ValueError("Campo 'cmd' obrigatório")
    if msg["cmd"] not in ["F", "R", "L", "D", "S"]:
        raise ValueError(f"Comando desconhecido: {msg['cmd']}")
except json.JSONDecodeError:
    logger.error(f"JSON inválido: {line}")
```

### MQTT em roteador

```python
def rotear(payload: dict):
    """Valida antes de despachar."""
    cmd_tipo = payload.get("cmd")
    if not isinstance(cmd_tipo, str):
        raise TypeError("cmd deve ser string")
    if len(cmd_tipo) > 20:
        raise ValueError("cmd muito longo")
    
    # Depois de validado, despacha
    _ROTAS[cmd_tipo].rotear(payload)
```

### SQL em API

```python
# NÃO FAÇA ASSIM:
cursor.execute(f"SELECT * FROM telemetria WHERE campo = '{user_field}'")  # Injeção!

# FAÇA ASSIM:
cursor.execute("SELECT * FROM telemetria WHERE campo = %s", (user_field,))
```

**Validação em `cloud/api/app/consultas.py`:**
```python
INTERVALOS = ["1m", "5m", "1h", "1d"]  # Whitelist

def get_telemetria(intervalo: str, campo: str):
    if intervalo not in INTERVALOS:
        raise ValueError(f"intervalo não permitido: {intervalo}")
    if campo not in ["temperatura", "pressao", "umidade"]:  # Whitelist
        raise ValueError(f"campo não permitido: {campo}")
    
    sql = f"SELECT time_bucket('{intervalo}', tempo) AS bucket, AVG({campo}) AS valor FROM telemetria GROUP BY bucket"
    # Agora intervalo e campo são seguros (vieram da whitelist)
    cursor.execute(sql)
```

---

## 🧪 Testes de Segurança

### Teste: Parada de Emergência

```python
def test_parada_emergencia():
    motor = ServicoMotores()
    
    # Motor andando
    motor.on_message(client, None, Msg("robo/motores/velocidade", '{"esq": 0.5, "dir": 0.5}'))
    assert motor.velocidade_atual == 0.5
    
    # Parada de emergência
    motor.on_message(client, None, Msg("robo/motores/parada", '{}'))
    assert motor.velocidade_atual == 0.0
    
    # Rampa desacelera, não para instantaneamente
    sleep(0.1)
    # Validar que GPIO não recebeu comando inválido
    assert gpio_history[-1].valid
```

### Teste: Sem Race Condition

```python
# motores/tests/test_concorrencia.py — 12 casos
def test_concorrencia_apply_tick():
    """Verifica que aplicar() em uma thread não interrompe tick() em outra."""
    ...
```

### Teste: Exclusão Mútua

```python
def test_rlock_bloqueia():
    """Confirma que RLock funciona."""
    s = ServicoMotores()
    
    # Adquire lock na main thread
    with s.lock:
        # Tenta adquirir em outra thread
        acquired = s.lock.acquire(timeout=0.1)
        assert not acquired  # Bloqueado!
        
        # RLock é reentrante
        acquired_again = s.lock.acquire(timeout=0.1)
        assert acquired_again  # Mesmo thread consegue!
        s.lock.release()
```

---

## ✅ Checklist de Segurança para Novo Recurso

- [ ] Input validation — toda entrada é validada?
- [ ] Rate limiting — há proteção contra spam?
- [ ] Authentication — requer token/senha?
- [ ] Authorization — apenas usuários permitidos conseguem?
- [ ] Encryption — dados sensíveis criptografados em trânsito?
- [ ] Database — usando parameterized queries?
- [ ] Logging — eventos de segurança são registrados?
- [ ] Testing — testes de segurança escritos?
- [ ] Documentation — comportamento documentado (inclusive falhas)?

---

Veja também: [[../arquitetura/como-funciona.md]], [[../modulos/python-services.md]]
