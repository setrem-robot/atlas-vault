# Setup Completo — Guia Passo a Passo

Instruções para deixar SetremBot rodando localmente (dev) e na nuvem (prod).

---

## 📋 Pré-requisitos

### Hardware (Desenvolvimento Local)

- [ ] Raspberry Pi 4B (4GB RAM) ou computador Linux
- [ ] ESP32 dev board (com BLE)
- [ ] Motores NEMA17 + drivers TMC2209 (ou use simulado)
- [ ] GPS u-blox (ou use simulado)
- [ ] Bateria 12V + regulador para 5V (Pi e ESP32)

### Software

- [ ] Python 3.11+
- [ ] pip, venv
- [ ] Docker + Docker Compose (para cloud)
- [ ] Git
- [ ] Arduino IDE ou PlatformIO (para ESP32)

---

## 🔧 Parte 1: Firmware ESP32

### 1.1 Clonar e preparar

```bash
cd ~/projetos
git clone <repo-esp32>
cd esp32/esp32_ble_bridge
```

### 1.2 Configurar Arduino IDE

**Ou PlatformIO:**
```bash
pip install platformio
```

**Arquivos importantes:**
```
esp32.ino                    — Entry point
├── setup()                  — Inicializa BLE
├── loop()                   — Lê BLE, escreve Serial
└── onConnect/onDisconnect   — Observadores
```

### 1.3 Flash no ESP32

```bash
# Via Arduino IDE:
# 1. Selecionar placa: ESP32 Dev Module
# 2. Porta: /dev/ttyUSB0 (ou COM3)
# 3. Baud rate: 115200
# 4. Clicar "Upload"

# Via PlatformIO:
pio run -t upload -e esp32
```

### 1.4 Verificar

```bash
# Abrir Serial Monitor
# Esperado:
# BLE Server started
# Waiting for connections...
```

---

## 🐍 Parte 2: Serviços Python (Raspberry Pi ou Dev)

### 2.1 Setup do venv

```bash
cd orquestrador/pi/services
python3 -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate  # Windows

pip install --upgrade pip setuptools wheel
```

### 2.2 Instalar dependências

```bash
# Instalar biblioteca compartilhada
pip install -e _common/

# Instalar serviços
pip install -e serial_ingestor/
pip install -e orquestrador/
pip install -e motores/
pip install -e gps/
pip install -e wifi/
```

### 2.3 Configurar variáveis de ambiente

```bash
# Criar .env local
cat > .env <<'ENVEOF'
# Serial
SERIAL_PORT=/dev/ttyUSB0
SERIAL_BAUD=115200

# MQTT Local
MQTT_BROKER_LOCAL=localhost
MQTT_PORT_LOCAL=1883

# MQTT Remoto (deixar em branco para usar local só)
MQTT_BROKER_REMOTE=
MQTT_USERNAME_REMOTE=
MQTT_PASSWORD_REMOTE=

# Motores
MOTORES_BACKEND=simulado  # ou "stepper" se tem hardware
GPIO_PIN_STEP_ESQ=17
GPIO_PIN_DIR_ESQ=18
GPIO_PIN_STEP_DIR=27
GPIO_PIN_DIR_DIR=22

# GPS (deixar vazio para não usar)
GPS_DEVICE=

# WiFi
WIFI_INTERFACE=wlan0
ENVEOF
```

### 2.4 Iniciar Mosquitto

```bash
# Se não tiver instalado:
sudo apt-get install mosquitto mosquitto-clients

# Iniciar:
mosquitto -c /etc/mosquitto/mosquitto.conf

# Ou com Docker:
docker run -d -p 1883:1883 eclipse-mosquitto:latest
```

### 2.5 Rodar serviços (modo dev)

```bash
# Terminal 1: serial_ingestor
cd pi/services/serial_ingestor
python -m serial_ingestor.main

# Terminal 2: orquestrador
cd pi/services/orquestrador
python -m orquestrador.main

# Terminal 3: motores
cd pi/services/motores
python -m motores.main

# Terminal 4: gps (opcional)
cd pi/services/gps
python -m gps.main

# Terminal 5: wifi (opcional)
cd pi/services/wifi
python -m wifi.main
```

### 2.6 Testar comunicação

```bash
# Monitorar tópicos
mosquitto_sub -t "robo/#" -v

# Em outro terminal, enviar comando
mosquitto_pub -t "robo/comando/entrada" -m '{"cmd":"F"}'

# Esperado:
robo/comando/entrada {"cmd":"F"}
robo/motores/velocidade {...}
robo/telemetria/motores {...}
```

---

## ☁️ Parte 3: Cloud — Docker Compose

### 3.1 Preparar ambiente

```bash
cd orquestrador/cloud
docker-compose --version  # Verificar que está instalado
```

### 3.2 Criar arquivo .env

```bash
cat > .env <<'ENVEOF'
POSTGRES_PASSWORD=senha_forte_123
POSTGRES_USER=postgres
POSTGRES_DB=robo_telemetria

MOSQUITTO_USERNAME=robo_telemetria
MOSQUITTO_PASSWORD=mqtt_password_123

CLOUDFLARE_TUNNEL_TOKEN=seu_token_aqui  # Opcional, para exposição HTTPS

TIMESCALEDB_ADMIN_USER=admin_ts
TIMESCALEDB_ADMIN_PASSWORD=ts_password_456
ENVEOF
```

### 3.3 Iniciar stack

```bash
docker-compose up -d

# Verificar status
docker-compose ps
docker-compose logs -f

# Esperado:
# mosquitto    | 1663050000.123 | mosquitto version 2.x running
# timescaledb  | database system is ready to accept connections
# ingestor     | Connected to Mosquitto
# api          | Application startup complete
```

### 3.4 Validar banco de dados

```bash
# Conectar ao banco
docker-compose exec timescaledb psql -U postgres -d robo_telemetria

# Inside psql:
\dt                            # Listar tabelas
SELECT * FROM telemetria_motores LIMIT 5;
```

---

## 📱 Parte 4: App Flutter

### 4.1 Clonar e preparar

```bash
cd ~/projetos
git clone <repo-app>
cd app
flutter pub get
```

### 4.2 Configurar URLs de API

```dart
// lib/config/api_config.dart
class ApiConfig {
  static const String apiBaseUrl = "http://192.168.1.100:8000/v1";
  static const String apiPublicBaseUrl = "http://192.168.1.100:8000/v1/publico";
  static const String bearerToken = "seu_token_aqui";
}
```

### 4.3 Rodar no Android/iOS

```bash
# Android
flutter run -d <device-id>

# iOS (requer macOS)
flutter run -d <device-id>

# Web
flutter run -d chrome
```

---

## 🚀 Deployment em Produção

### Setup Raspberry Pi (systemd)

```bash
# Criar serviços systemd
sudo bash pi/services/scripts/install.sh

# Verificar status
sudo systemctl status robo-serial-ingestor
sudo systemctl status robo-orquestrador
sudo systemctl status robo-motores
sudo systemctl status robo-gps
sudo systemctl status robo-wifi

# Ver logs
sudo journalctl -u robo-motores -f

# Reiniciar
sudo systemctl restart robo-motores
```

### Cloud (Kubernetes)

```bash
# Deploy usando kubectl
kubectl apply -f orquestrador/cloud/k8s/
kubectl get pods
kubectl logs -f deployment/api
```

---

## 📊 Checklist Final

- [ ] ESP32 conecta por BLE e repassa JSON
- [ ] serial_ingestor lê UART e publica em MQTT
- [ ] Roteador despacha comandos para motores
- [ ] Motores recebem e movem (ou simulam)
- [ ] Telemetria chega em cloud
- [ ] API retorna dados
- [ ] App Flutter conecta e controla
- [ ] Parada de emergência funciona
- [ ] Todos os 5 serviços têm status `active (running)`

---

Veja também: [[../../orquestrador/docs/ambiente-local.md]], [[../api/contrato-mqtt.md]]
