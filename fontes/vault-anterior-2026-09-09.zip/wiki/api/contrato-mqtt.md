# Contrato MQTT — Especificação Completa

Todos os tópicos, formatos de payload, QoS, validações e exemplos.

---

## Tópicos de Comando (Entrada)

### robo/comando/entrada

**QoS:** 1 (at-least-once)  
**Retain:** false  
**Origem:** `serial_ingestor` (lê UART)  
**Consumidor:** `roteador`

**Payload:**
```json
{
  "cmd": "F"  // "F" | "R" | "L" | "D" | "S"
}
```

| Valor | Significado | Efeito |
|-------|-------------|--------|
| `"F"` | Frente | Velocidade linear positiva |
| `"R"` | Ré | Velocidade linear negativa |
| `"L"` | Esquerda | Velocidade angular negativa (CCW) |
| `"D"` | Direita | Velocidade angular positiva (CW) |
| `"S"` | Stop | Velocidade = 0 |

**Validação:**
```python
assert cmd in ["F", "R", "L", "D", "S"]
assert isinstance(cmd, str)
assert len(cmd) == 1
```

**Exemplo:**
```bash
mosquitto_pub -t "robo/comando/entrada" -m '{"cmd":"F"}'
```

---

## Tópicos de Telemetria (Saída)

### robo/telemetria/motores

**QoS:** 1  
**Retain:** true  
**Origem:** `motores` (serviço)  
**Consumidor:** `ingestor` (cloud)

**Payload:**
```json
{
  "posicao": 1234.5,           // Encoder ticks acumulados
  "velocidade_esq": 0.5,       // -1 a 1, rpm normalizado
  "velocidade_dir": 0.5,       // -1 a 1, rpm normalizado
  "rampa_esq": 0.45,           // Valor intermediário (aceleração)
  "rampa_dir": 0.45,           // Valor intermediário (aceleração)
  "timestamp": 1663050000.123  // Unix timestamp (float)
}
```

**Frequência:** ~20 Hz (a cada 50 ms de `main()`)

**Validação:**
```python
assert isinstance(payload["posicao"], (int, float))
assert -1 <= payload["velocidade_esq"] <= 1
assert -1 <= payload["velocidade_dir"] <= 1
assert payload["timestamp"] > 0
```

### robo/telemetria/gps

**QoS:** 1  
**Retain:** true  
**Origem:** `gps` (serviço)  
**Consumidor:** `ingestor` (cloud)

**Payload:**
```json
{
  "latitude": -27.78919,          // Decimal degrees
  "longitude": -55.47889,         // Decimal degrees
  "altitude": 243.5,              // Metros
  "speed": 1.2,                   // m/s
  "accuracy": 5.0,                // Metros (HDOP)
  "timestamp": 1663050000.123,    // Unix timestamp
  "status": "fix"                 // "fix" | "no_fix" | "error"
}
```

**Frequência:** 1 Hz (update do GPS)

### robo/telemetria/bateria

**QoS:** 1  
**Retain:** true  
**Origem:** ADC sensor (serviço próprio?)  
**Consumidor:** `ingestor`

**Payload:**
```json
{
  "tensao": 12.5,                 // Volts
  "corrente": 2.3,                // Amperes
  "percentual": 85,               // 0-100%
  "temperatura": 35.2,            // Celsius
  "timestamp": 1663050000.123
}
```

---

## Tópicos de Controle

### robo/motores/velocidade

**QoS:** 1  
**Retain:** false  
**Origem:** `roteador`  
**Consumidor:** `motores`

**Payload:**
```json
{
  "linear": 0.5,                  // -1 a 1, velocidade linear
  "angular": 0.0,                 // -1 a 1, velocidade angular
  "lado_esquerdo": 0.5,           // Resultado cinematica
  "lado_direito": 0.5,            // Resultado cinematica
  "timestamp": 1663050000.123
}
```

**Conversão de comando → velocidade:**
```python
def comando_para_velocidade(cmd):
    mapping = {
        "F": {"linear": 0.5, "angular": 0},
        "R": {"linear": -0.5, "angular": 0},
        "L": {"linear": 0, "angular": -0.5},
        "D": {"linear": 0, "angular": 0.5},
        "S": {"linear": 0, "angular": 0}
    }
    return mapping.get(cmd, {})
```

### robo/motores/parada

**QoS:** 1  
**Retain:** false  
**Origem:** `roteador` ou `motores` (vigia)  
**Consumidor:** `motores`

**Payload:**
```json
{}
```

ou

```json
{
  "motivo": "vigia",              // "vigia" | "comando" | "emergencia"
  "timestamp": 1663050000.123
}
```

---

## Tópicos de WiFi

### robo/wifi/status

**QoS:** 1  
**Retain:** true  
**Origem:** `wifi` (serviço)  
**Consumidor:** `ingestor`

**Payload:**
```json
{
  "ssid": "SETREM-Guest",         // SSID conectado
  "signal_strength": -45,         // dBm (-30 a -90)
  "ip": "192.168.1.100",          // IPv4
  "gateway": "192.168.1.1",       // Rota default
  "dns": ["8.8.8.8"],             // Servidores DNS
  "timestamp": 1663050000.123
}
```

### robo/wifi/comando

**QoS:** 1  
**Retain:** false  
**Origem:** `roteador`  
**Consumidor:** `wifi`

**Payload:**
```json
{
  "ssid": "NovaRede",             // SSID alvo
  "psk": "senha_wpa2",            // Pre-shared key
  "timestamp": 1663050000.123
}
```

---

## Tópicos de Diagnóstico

### robo/diagnostico/uptime

**QoS:** 1  
**Retain:** true  
**Origem:** `main.py` (cada serviço)  
**Consumidor:** `ingestor`

**Payload:**
```json
{
  "servico": "motores",           // Nome do serviço
  "uptime_s": 36000,              // Segundos desde boot
  "versao": "1.2.3",              // Versão do código
  "timestamp": 1663050000.123
}
```

---

## Validação em Nível de Broker

### Autorização por Tópico

```
User: serial_ingestor
  Publish: robo/comando/entrada
  Subscribe: -

User: orquestrador
  Publish: robo/motores/velocidade, robo/motores/parada, robo/wifi/comando
  Subscribe: robo/comando/entrada

User: motores
  Publish: robo/telemetria/motores, robo/motores/parada
  Subscribe: robo/motores/velocidade, robo/motores/parada

User: gps
  Publish: robo/telemetria/gps
  Subscribe: (nenhum)

User: wifi
  Publish: robo/telemetria/wifi, robo/wifi/status
  Subscribe: robo/wifi/comando

User: ingestor_cloud
  Publish: (nenhum)
  Subscribe: robo/telemetria/#
```

---

## Ordem de Inicialização Esperada

1. **Mosquitto** inicia, aguarda conexões
2. **serial_ingestor** conecta, fica escutando UART
3. **orquestrador** conecta, fica escutando `robo/comando/entrada`
4. **motores** conecta, fica escutando `robo/motores/*`
5. **gps** conecta, começa a publicar telemetria
6. **wifi** conecta, começa a publicar status
7. **App Flutter** conecta por BLE
8. **Usuário** envia comando
9. Fluxo de dados começa

**Timeout esperado:** 5 segundos do boot até pronto.

---

## Exemplo: Sessão Completa

```
# Terminal 1: Monitor de tópicos
$ mosquitto_sub -t "robo/#" -v

# Terminal 2: Enviar comando
$ mosquitto_pub -t "robo/comando/entrada" -m '{"cmd":"F"}'

# Saída esperada:
robo/comando/entrada {"cmd":"F"}
robo/motores/velocidade {"linear": 0.5, "angular": 0, ...}
robo/telemetria/motores {"posicao": 1234.5, "velocidade_esq": 0.5, ...}
robo/telemetria/motores {"posicao": 1235.2, "velocidade_esq": 0.52, ...}
...
# (1 segundo depois — vigia ativa)
robo/motores/parada {"motivo": "vigia"}
robo/telemetria/motores {"posicao": 1250.0, "velocidade_esq": 0.0, ...}
```

---

Veja também: [[../arquitetura/mapa-comunicacao.md]], [[../configuracao/setup-completo.md]]
