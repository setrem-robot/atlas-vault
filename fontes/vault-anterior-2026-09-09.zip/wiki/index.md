# AtlasVault — Cérebro Completo do SetremBot

**Visão geral:** Documentação estruturada, código-fonte anotado, arquitetura, segurança, configuração e histórico do **SetremBot** — robô educacional autônomo com controle remoto, telemetria na nuvem e interface web/móvel.

---

## 📋 Índice Principal

### **[Arquitetura](./arquitetura/visao-geral.md)**
- Visão geral: três repositórios, cinco serviços, uma nuvem
- Fluxo de dados: do botão até o motor, telemetria de volta
- Decisões de desenho: por que cada coisa é como é
- Comunicação: MQTT, BLE, HTTPS

### **[Módulos](./modulos/index.md)**
- **ESP32 BLE Bridge** — firmware C++, ponte BLE ↔ Serial
- **Serviços Python (Raspberry Pi)** — orquestrador, motores, GPS, WiFi, serial_ingestor
- **API Cloud (FastAPI)** — leitura de telemetria, rotas públicas/privadas
- **App Flutter** — interface iOS/Android

### **[Segurança](./seguranca/index.md)**
- Movimento repetido, silêncio é "pare" — 4 camadas independentes
- Exclusão mútua em motores (RLock)
- API read-only, acesso limitado ao banco
- BLE vs Bluetooth Classic — por que mudou

### **[Configuração](./configuracao/setup-completo.md)**
- Setup ESP32, Raspberry Pi, Cloud, site
- Variáveis de ambiente
- Serviços systemd
- Docker Compose na nuvem

### **[Hardware](./hardware/especificacoes.md)**
- Componentes: ESP32, Raspberry Pi, motores TMC2209, GPS, sensores
- Pinagem, conexões, alimentação
- Dimensionamento de corrente

### **[API](./api/contratos.md)**
- Endpoints REST com autenticação
- Contrato MQTT completo
- Formatos de dados

### **[Histórico & Relatórios](./historico/relatorios-semestre.md)**
- Relatórios de progresso (EstruturaPDF, InterfacePDF, OrquestradorPDF)
- Mudanças de arquitetura
- Pendências e próximos passos

---

## 🚀 Começar rápido

**Quero entender a comunicação:**
→ Leia [MAPA-COMUNICACAO.md](./arquitetura/mapa-comunicacao.md)

**Quero rodar o projeto localmente:**
→ [Setup local](./configuracao/setup-completo.md) → [Ambiente da máquina](./configuracao/ambiente-local.md)

**Quero entender a cinemática dos motores:**
→ [Motores: 3 camadas](./modulos/motores.md)

**Quero integrar uma nova funcionalidade:**
→ [Como funciona (ponta a ponta)](./arquitetura/como-funciona.md) → [Contrato MQTT](./api/contrato-mqtt.md)

---

## 📁 Estrutura do Vault

```
AtlasVault/
├── wiki/
│   ├── arquitetura/      — desenho, decisões, fluxos
│   ├── modulos/          — código-fonte comentado
│   ├── seguranca/        — safety, concorrência, auth
│   ├── api/              — contratos MQTT, REST, dados
│   ├── configuracao/     — setup, env, deploy
│   ├── hardware/         — componentes, pinagem
│   ├── historico/        — relatórios, changelog
│   └── meta/ledgers/     — (persistência do vault)
├── inbox/                — sources novos a ingerir
└── .raw/                 — arquivos imutáveis
```

---

## 📊 Status do Vault

- **Versão:** 1.0.0
- **Data de criação:** 2026-09-09
- **Fontes:** CLAUDE.md, docs/, código-fonte, PDFs de relatórios
- **Cobertura:** ~100% da arquitetura e configuração

---

## 🔄 Como manter este vault

1. Novas features → adicione .md em `modulos/`
2. Mudança de contrato → atualize `api/contrato-mqtt.md`
3. Novo setup → registre em `configuracao/`
4. Bug/decisão importante → log em `historico/changelog.md`

---

## 📞 Contexto

SetremBot é um projeto de **robótica educacional** da **SETREM** (faculdade). Começou como uma monografia sobre **controle de robôs via rede** e evoluiu para um sistema multi-repositório com:

- **Firmware** em C++ (ESP32)
- **Backend** em Python (Raspberry Pi + Cloud)
- **Frontend** em Flutter + web HTML/CSS/JS

Este vault organiza todo aquele conhecimento em um lugar navegável, versionado, offline-first.
